-- Add missing columns
ALTER TABLE astronaut_log ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE seed_cartridges ADD COLUMN IF NOT EXISTS pod_id text;
ALTER TABLE seed_cartridges ADD COLUMN IF NOT EXISTS prescribed_for uuid REFERENCES auth.users(id);

-- Create missing tables
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('paciente', 'doctor', 'programador', 'admin')),
  full_name text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS profile_views (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  viewer_id uuid REFERENCES auth.users(id),
  patient_id uuid REFERENCES auth.users(id),
  viewed_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS access_requests (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  email text NOT NULL,
  requested_role text NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at timestamptz DEFAULT now()
);

-- Fix infinite recursion: SECURITY DEFINER bypasses RLS when checking role
CREATE OR REPLACE FUNCTION get_my_role()
RETURNS text
LANGUAGE sql
SECURITY DEFINER
STABLE
AS $$
  SELECT role FROM user_profiles WHERE id = auth.uid();
$$;

-- Enable RLS
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE astronaut_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE seed_cartridges ENABLE ROW LEVEL SECURITY;
ALTER TABLE profile_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE access_requests ENABLE ROW LEVEL SECURITY;

-- RLS policies using get_my_role() — no infinite recursion
DROP POLICY IF EXISTS "user_profiles_own" ON user_profiles;
CREATE POLICY "user_profiles_own" ON user_profiles
  FOR SELECT USING (auth.uid() = id);

DROP POLICY IF EXISTS "user_profiles_doctor_read" ON user_profiles;
CREATE POLICY "user_profiles_doctor_read" ON user_profiles
  FOR SELECT USING (get_my_role() IN ('doctor','admin'));

DROP POLICY IF EXISTS "astronaut_log_own" ON astronaut_log;
CREATE POLICY "astronaut_log_own" ON astronaut_log
  FOR ALL USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "astronaut_log_doctor_read" ON astronaut_log;
CREATE POLICY "astronaut_log_doctor_read" ON astronaut_log
  FOR SELECT USING (get_my_role() IN ('doctor','admin'));

DROP POLICY IF EXISTS "seed_cartridges_read" ON seed_cartridges;
CREATE POLICY "seed_cartridges_read" ON seed_cartridges
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "seed_cartridges_write" ON seed_cartridges;
CREATE POLICY "seed_cartridges_write" ON seed_cartridges
  FOR ALL USING (get_my_role() IN ('doctor','admin','programador'));

DROP POLICY IF EXISTS "profile_views_insert" ON profile_views;
CREATE POLICY "profile_views_insert" ON profile_views
  FOR INSERT WITH CHECK (auth.uid() = viewer_id);

DROP POLICY IF EXISTS "profile_views_own" ON profile_views;
CREATE POLICY "profile_views_own" ON profile_views
  FOR SELECT USING (auth.uid() = patient_id);

DROP POLICY IF EXISTS "access_requests_insert" ON access_requests;
CREATE POLICY "access_requests_insert" ON access_requests
  FOR INSERT WITH CHECK (true);

DROP POLICY IF EXISTS "access_requests_admin" ON access_requests;
CREATE POLICY "access_requests_admin" ON access_requests
  FOR ALL USING (get_my_role() = 'admin');

-- User profiles
INSERT INTO user_profiles (id, role, full_name) VALUES
  ('07b0d117-92c2-4a65-aece-7a8d7333e981', 'admin',       'Admin EDEN'),
  ('84bc8db3-8e46-449e-bc02-268d62901307', 'programador', 'Dev EDEN'),
  ('9e552e43-8fb7-48b7-af38-263ec41fe5d8', 'doctor',      'Dr. EDEN'),
  ('0f79228a-8f4b-47f5-bf88-a130cbc1f4d2', 'paciente',    'Astronaut EDEN')
ON CONFLICT (id) DO UPDATE SET role = EXCLUDED.role, full_name = EXCLUDED.full_name;

-- Plants first (seed_cartridges has FK → plants)
-- English content, no "pastillas", explicit IDs
DELETE FROM seed_cartridges;
DELETE FROM plants;

INSERT INTO plants (id, plant_name, condition, dose, active_compound, effect, grow_time_days)
OVERRIDING SYSTEM VALUE VALUES
  (1, 'Ashwagandha', 'Stress, anxiety, fatigue', '300 mg extract, twice daily with meals', 'Withanolides', 'Adaptogen — reduces cortisol, supports adrenal function and resilience under chronic stress', 45),
  (2, 'Turmeric', 'Inflammation, joint pain, muscle soreness', '500 mg curcumin extract, twice daily', 'Curcumin', 'Anti-inflammatory — inhibits NF-kB pathway; aids recovery after physical exertion', 60),
  (3, 'Lavender', 'Insomnia, anxiety, restlessness', '80 mg oral extract at bedtime', 'Linalool / Linalyl acetate', 'Anxiolytic and sleep aid — modulates GABA receptors; calms the central nervous system', 30),
  (4, 'Moringa', 'Fatigue, vitamin deficiency, low energy', '2 g leaf powder, once daily with water', 'Isothiocyanates / Quercetin', 'Nutritional supplement — rich in vitamins A, C, E and iron; counteracts space-related micronutrient loss', 25),
  (5, 'Peppermint', 'Nausea, headache, cognitive fatigue', '250 mg enteric-coated oil capsule, up to three times daily', 'Menthol', 'Antispasmodic and mental stimulant — relieves GI discomfort and refreshes alertness', 20),
  (6, 'Rosemary', 'Poor focus, memory, cognitive decline', '500 mg dry extract, once daily in the morning', 'Rosmarinic acid / Carnosol', 'Nootropic — improves acetylcholine availability; enhances concentration and short-term memory', 35),
  (7, 'Garlic', 'Elevated heart rate, cardiovascular stress', '600 mg aged extract, once daily', 'Allicin', 'Cardiovascular support — lowers blood pressure and LDL; reduces vascular inflammation', 40),
  (8, 'Basil', 'Bone density loss, long-duration spaceflight', '1 g fresh leaf equivalent, twice daily', 'Eugenol / Ursolic acid', 'Bone and immune support — anti-inflammatory; contributes calcium and magnesium for skeletal health', 22);

-- Seed pods — after plants exist
INSERT INTO seed_cartridges (slot, pod_id, plant_id, status, prescribed_for) VALUES
  (1, 'ASH-Gen2-001', 1, 'ready',     '0f79228a-8f4b-47f5-bf88-a130cbc1f4d2'),
  (2, 'CUR-Gen2-001', 2, 'growing',   '0f79228a-8f4b-47f5-bf88-a130cbc1f4d2'),
  (3, 'LAV-Gen2-001', 3, 'planted',   NULL),
  (4, 'MOR-Gen2-001', 4, 'empty',     NULL),
  (5, 'MEN-Gen2-001', 5, 'ready',     '0f79228a-8f4b-47f5-bf88-a130cbc1f4d2'),
  (6, 'ASH-Gen2-002', 1, 'harvested', NULL);

-- Reset passwords
UPDATE auth.users SET encrypted_password = crypt('eden2026', gen_salt('bf'))
WHERE email IN ('atronaut@eden.space', 'doctor@eden.space', 'progra@eden.space', 'admin@eden.space');
