import { BrowserRouter, Routes, Route, NavLink, Navigate } from 'react-router-dom'
import { createContext, useContext, useEffect, useState } from 'react'
import { supabase } from './lib/supabase'
import { getProfile, signOut } from './lib/auth'

import Dashboard    from './pages/Dashboard'
import HealthCheck  from './pages/HealthCheck'
import PlantMonitor from './pages/PlantMonitor'
import MissionLog   from './pages/MissionLog'
import Login        from './pages/Login'
import Settings     from './pages/Settings'

// ─── Auth Context ────────────────────────────────────────────────────────────
const AuthContext = createContext(null)

export function useAuth() {
  return useContext(AuthContext)
}

function AuthProvider({ children }) {
  const [user,    setUser]    = useState(undefined)
  const [profile, setProfile] = useState(null)

  useEffect(() => {
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      setUser(session?.user ?? null)
      if (session?.user) {
        const p = await getProfile()
        setProfile(p)
      }
    })

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        setUser(session?.user ?? null)
        if (session?.user) {
          const p = await getProfile()
          setProfile(p)
        } else {
          setProfile(null)
        }
      }
    )
    return () => subscription.unsubscribe()
  }, [])

  async function logout() {
    await signOut()
    setUser(null)
    setProfile(null)
  }

  return (
    <AuthContext.Provider value={{ user, profile, logout, loading: user === undefined }}>
      {children}
    </AuthContext.Provider>
  )
}

// ─── Protected routes ────────────────────────────────────────────────────────
function ProtectedRoute({ children, allowedRoles }) {
  const { user, profile, loading } = useAuth()

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#FBFBF8]">
        <div className="text-[#6AA6DA] font-mono text-sm animate-pulse">Initializing E.D.E.N. systems...</div>
      </div>
    )
  }

  if (!user) return <Navigate to="/login" replace />

  if (allowedRoles && profile && !allowedRoles.includes(profile.role)) {
    return <Navigate to="/" replace />
  }

  return children
}

// ─── Nav by role ─────────────────────────────────────────────────────────────
function getNav(role) {
  if (role === 'paciente') return [
    { to: '/',        label: 'Dashboard'     },
    { to: '/health',  label: 'Health Check'  },
    { to: '/plants',  label: 'Plant Monitor' },
    { to: '/log',     label: 'Mission Log'   },
    { to: '/settings',label: 'Settings'      },
  ]
  if (role === 'doctor') return [
    { to: '/',          label: 'Dashboard'    },
    { to: '/patients',  label: 'Patients'     },
    { to: '/plantlog',  label: 'Plant Log'    },
    { to: '/log',       label: 'Mission Log'  },
    { to: '/settings',  label: 'Settings'     },
  ]
  if (role === 'programador') return [
    { to: '/',         label: 'Dashboard'    },
    { to: '/system',   label: 'System Info'  },
    { to: '/plants',   label: 'Plants DB'    },
    { to: '/log',      label: 'All Logs'     },
    { to: '/settings', label: 'Settings'     },
  ]
  if (role === 'admin') return [
    { to: '/',          label: 'Dashboard'       },
    { to: '/requests',  label: 'Access Requests' },
    { to: '/users',     label: 'Users'           },
    { to: '/settings',  label: 'Settings'        },
  ]
  // fallback
  return [
    { to: '/',         label: 'Dashboard'    },
    { to: '/health',   label: 'Health Check' },
    { to: '/plants',   label: 'Plant Monitor'},
    { to: '/log',      label: 'Mission Log'  },
    { to: '/settings', label: 'Settings'     },
  ]
}

// ─── Sidebar ─────────────────────────────────────────────────────────────────
export function Sidebar() {
  const { profile, logout } = useAuth()
  const nav = getNav(profile?.role)

  const roleColor = {
    paciente:    'text-[#6AA6DA]',
    doctor:      'text-[#4ade80]',
    programador: 'text-[#E1E5AC]',
    admin:       'text-orange-400',
  }[profile?.role] || 'text-black/40'

  return (
    <aside className="flex flex-col w-56 shrink-0 bg-white border-r border-black/8 h-screen sticky top-0">
      <div className="px-6 py-6 border-b border-black/8">
        <p className="text-black font-bold text-sm tracking-widest uppercase">E.D.E.N.</p>
        <p className="text-black/40 text-[10px] font-mono mt-0.5">Ecosystem Diagnostic</p>
      </div>

      {profile && (
        <div className="px-5 py-3 border-b border-black/8">
          <p className="text-black/70 text-xs font-medium truncate">{profile.full_name}</p>
          <p className={`text-[10px] font-mono uppercase tracking-wider ${roleColor}`}>
            {{ paciente: 'Patient', doctor: 'Doctor', programador: 'Engineer', admin: 'Admin' }[profile.role] ?? profile.role}
          </p>
        </div>
      )}

      <nav className="flex-1 py-4 px-3 space-y-0.5 overflow-y-auto">
        {nav.map(({ to, label }) => (
          <NavLink key={to} to={to} end={to === '/'}
            className={({ isActive }) =>
              `block px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-[#6AA6DA]/15 text-[#6AA6DA] border border-[#6AA6DA]/30'
                  : 'text-black/40 hover:text-black/70 hover:bg-black/5'
              }`
            }
          >{label}</NavLink>
        ))}
      </nav>

      <div className="px-5 py-4 border-t border-black/8 space-y-2">
        <button
          onClick={logout}
          className="w-full text-left text-black/30 hover:text-black/60 text-[10px] font-mono transition-colors"
        >
          Sign Out
        </button>
        <p className="text-black/25 text-[10px] font-mono">NASA Space Apps 2026</p>
        <p className="text-black/15 text-[10px] font-mono">Team Dyeus</p>
      </div>
    </aside>
  )
}

// ─── Layout ───────────────────────────────────────────────────────────────────
export function Layout({ children }) {
  return (
    <div className="flex min-h-screen bg-[#FBFBF8]">
      <Sidebar />
      <main className="flex-1 overflow-auto p-6 lg:p-8">
        {children}
      </main>
    </div>
  )
}

// ─── ADMIN: Mission Dashboard ────────────────────────────────────────────────
function AdminDashboard() {
  const [stats,    setStats]    = useState(null)
  const [requests, setRequests] = useState([])

  useEffect(() => {
    Promise.all([
      supabase.from('user_profiles').select('*', { count: 'exact', head: true }),
      supabase.from('astronaut_log').select('*', { count: 'exact', head: true }),
      supabase.from('access_requests').select('*').eq('status', 'pending').order('created_at', { ascending: false }).limit(5),
      supabase.from('user_profiles').select('*').eq('role', 'paciente'),
    ]).then(([users, logs, reqs, patients]) => {
      setStats({ users: users.count, logs: logs.count })
      setRequests(reqs.data ?? [])
    })
  }, [])

  const MISSION = { id: 'ALPHA-1', name: 'ISS Mission Alpha', status: 'ACTIVE', crew: 4 }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-lg font-bold text-black">Admin Dashboard</h1>
        <p className="text-black/30 text-xs font-mono mt-0.5">Mission control overview</p>
      </div>

      {/* Active missions */}
      <div>
        <p className="text-black/35 text-[10px] font-mono uppercase tracking-wider mb-3">Active Missions</p>
        <div className="bg-white border border-[#6AA6DA]/25 rounded-2xl p-5">
          <div className="flex items-start justify-between">
            <div>
              <p className="font-bold text-black">{MISSION.name}</p>
              <p className="text-black/40 text-xs font-mono mt-0.5">{MISSION.id}</p>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full border border-[#4ade80]/40 bg-[#4ade80]/10 text-[#4ade80]">
              {MISSION.status}
            </span>
          </div>
          <div className="grid grid-cols-3 gap-4 mt-5">
            {[
              { label: 'Crew Members', value: stats?.users ?? '—', color: '#6AA6DA' },
              { label: 'Log Entries',  value: stats?.logs  ?? '—', color: '#4ade80' },
              { label: 'Pending Req.', value: requests.length,     color: requests.length > 0 ? '#facc15' : '#4ade80' },
            ].map(({ label, value, color }) => (
              <div key={label} className="text-center">
                <p className="text-2xl font-bold font-mono" style={{ color }}>{value}</p>
                <p className="text-black/30 text-[10px] font-mono mt-0.5">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Pending requests snapshot */}
      <div>
        <p className="text-black/35 text-[10px] font-mono uppercase tracking-wider mb-3">Pending Access Requests</p>
        {requests.length === 0 ? (
          <div className="bg-white border border-black/8 rounded-2xl p-6 text-center text-black/20 font-mono text-xs">
            No pending requests
          </div>
        ) : (
          <div className="space-y-2">
            {requests.map(r => (
              <div key={r.id} className="bg-white border border-black/8 rounded-xl p-4 flex items-center justify-between">
                <div>
                  <p className="text-black font-medium text-sm">{r.full_name}</p>
                  <p className="text-black/30 text-[10px] font-mono">{r.email}</p>
                </div>
                <div className="text-right">
                  <span className="text-[#6AA6DA] text-xs font-mono">{r.role_requested}</span>
                  <p className="text-black/20 text-[10px] font-mono mt-0.5">{MISSION.id}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ─── ADMIN: Access Requests ───────────────────────────────────────────────────
function AdminRequests() {
  const [requests, setRequests] = useState([])
  const [loading,  setLoading]  = useState(true)

  useEffect(() => {
    supabase
      .from('access_requests')
      .select('*')
      .order('created_at', { ascending: false })
      .then(({ data }) => { setRequests(data || []); setLoading(false) })
  }, [])

  async function updateStatus(id, status) {
    await supabase.from('access_requests').update({ status }).eq('id', id)
    setRequests(prev => prev.map(r => r.id === id ? { ...r, status } : r))
  }

  const MISSION = 'ALPHA-1'

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-black">Access Requests</h1>
        <p className="text-black/30 text-xs font-mono mt-0.5">Mission {MISSION}</p>
      </div>
      {loading ? (
        <p className="text-black/40 font-mono text-sm">Loading...</p>
      ) : requests.length === 0 ? (
        <p className="text-black/30 text-sm">No requests found.</p>
      ) : (
        <div className="space-y-3">
          {requests.map(r => (
            <div key={r.id} className="bg-white border border-black/8 rounded-xl p-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <p className="text-black font-medium text-sm">{r.full_name}</p>
                    <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-[#6AA6DA]/10 text-[#6AA6DA] border border-[#6AA6DA]/20">
                      {MISSION}
                    </span>
                  </div>
                  <p className="text-black/40 text-xs font-mono">{r.email}</p>
                  <p className="text-[#6AA6DA] text-xs mt-1">Role requested: <span className="font-bold">{r.role_requested}</span></p>
                  {r.reason && <p className="text-black/40 text-xs mt-1 italic">"{r.reason}"</p>}
                </div>
                <div className="text-right shrink-0 space-y-2">
                  <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-mono uppercase ${
                    r.status === 'pending'  ? 'bg-[#E1E5AC]/50 text-[#7a7a00]' :
                    r.status === 'approved' ? 'bg-green-100 text-green-700'    :
                    'bg-red-100 text-red-600'
                  }`}>{r.status}</span>
                  {r.status === 'pending' && (
                    <div className="flex gap-1 justify-end">
                      <button onClick={() => updateStatus(r.id, 'approved')}
                        className="text-[10px] font-mono px-2 py-1 rounded-lg bg-green-50 text-green-700 border border-green-200 hover:bg-green-100 transition-all">
                        Approve
                      </button>
                      <button onClick={() => updateStatus(r.id, 'rejected')}
                        className="text-[10px] font-mono px-2 py-1 rounded-lg bg-red-50 text-red-600 border border-red-200 hover:bg-red-100 transition-all">
                        Reject
                      </button>
                    </div>
                  )}
                  <p className="text-black/20 text-[10px] font-mono">
                    {new Date(r.created_at).toLocaleString('en-US')}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ─── ADMIN: Users ─────────────────────────────────────────────────────────────
function AdminUsers() {
  const [users,    setUsers]    = useState([])
  const [loading,  setLoading]  = useState(true)
  const [editing,  setEditing]  = useState(null)
  const [editName, setEditName] = useState('')
  const [saving,   setSaving]   = useState(false)

  useEffect(() => {
    supabase
      .from('user_profiles')
      .select('*')
      .order('created_at', { ascending: false })
      .then(({ data }) => { setUsers(data || []); setLoading(false) })
  }, [])

  function openEdit(u) { setEditing(u); setEditName(u.full_name ?? '') }
  function closeEdit()  { setEditing(null); setEditName('') }

  async function saveEdit() {
    if (!editing) return
    setSaving(true)
    const { error } = await supabase
      .from('user_profiles')
      .update({ full_name: editName.trim() })
      .eq('id', editing.id)
    setSaving(false)
    if (!error) {
      setUsers(prev => prev.map(u => u.id === editing.id ? { ...u, full_name: editName.trim() } : u))
      closeEdit()
    }
  }

  const roleColor = {
    paciente:    'bg-[#6AA6DA]/15 text-[#6AA6DA]',
    doctor:      'bg-green-100 text-green-700',
    programador: 'bg-[#E1E5AC]/50 text-[#7a7a00]',
    admin:       'bg-orange-100 text-orange-700',
  }

  const MISSION = 'ALPHA-1'
  const grouped = { [MISSION]: users }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-black">Users</h1>
        <p className="text-black/30 text-xs font-mono mt-0.5">{users.length} registered</p>
      </div>

      {loading ? (
        <p className="text-black/40 font-mono text-sm">Loading...</p>
      ) : (
        Object.entries(grouped).map(([mission, mUsers]) => (
          <div key={mission}>
            <div className="flex items-center gap-2 mb-3">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#6AA6DA]/10 text-[#6AA6DA] border border-[#6AA6DA]/20">
                {mission}
              </span>
              <span className="text-black/25 text-[10px] font-mono">{mUsers.length} users</span>
            </div>
            <div className="space-y-2">
              {mUsers.map(u => (
                <div key={u.id} className="bg-white border border-black/8 rounded-xl p-4 flex items-center justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <p className="text-black font-medium text-sm">{u.full_name || '—'}</p>
                    <p className="text-black/30 text-[10px] font-mono truncate">{u.id}</p>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono uppercase ${roleColor[u.role] || 'bg-black/5 text-black/40'}`}>
                      {u.role}
                    </span>
                    <button onClick={() => openEdit(u)}
                      className="text-[10px] font-mono px-2 py-1 rounded-lg bg-[#FBFBF8] border border-black/10 text-black/40 hover:text-black/70 hover:border-black/20 transition-all">
                      Edit
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))
      )}

      {/* Edit modal */}
      {editing && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl">
            <h2 className="font-bold text-black mb-1">Edit User</h2>
            <p className="text-black/30 text-[10px] font-mono mb-4">{editing.id}</p>

            <label className="block text-black/40 text-[10px] font-mono uppercase tracking-wider mb-1.5">Full Name</label>
            <input
              type="text"
              value={editName}
              onChange={e => setEditName(e.target.value)}
              className="w-full bg-[#FBFBF8] border border-black/10 rounded-xl px-4 py-2.5 text-sm font-mono text-black/70 focus:outline-none focus:border-[#6AA6DA]/40 mb-4"
            />

            <div className="flex items-center gap-2 mb-2">
              <span className="text-black/30 text-xs font-mono">Role:</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono uppercase ${roleColor[editing.role] || 'bg-black/5 text-black/40'}`}>
                {editing.role}
              </span>
            </div>

            <div className="flex gap-2 mt-4">
              <button onClick={closeEdit}
                className="flex-1 py-2.5 rounded-xl border border-black/10 text-black/40 text-sm font-medium hover:bg-black/5 transition-all">
                Cancel
              </button>
              <button onClick={saveEdit} disabled={saving}
                className="flex-1 py-2.5 rounded-xl bg-[#6AA6DA] text-white text-sm font-bold hover:bg-[#5a96ca] disabled:opacity-40 transition-all">
                {saving ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Shared mission list (doctor views) ──────────────────────────────────────
const MISSIONS = [
  { id: 'ALPHA-1', name: 'ISS Mission Alpha', status: 'ACTIVE', crew: 3 },
]

function doctorOverallStatus(log) {
  if (!log) return 'NO DATA'
  const levels = [log.stress_level, log.inflammation_level, log.cognitive_level, log.cardiovascular_level]
  if (levels.some(l => l === 'HIGH' || l === 'ALTO' || l === 'CRITICO')) return 'CRITICAL'
  if (levels.some(l => l === 'MOD'  || l === 'MEDIO'))                   return 'CAUTION'
  return 'NOMINAL'
}

function doctorDisplayLevel(v) {
  const map = { ALTO: 'HIGH', CRITICO: 'CRITICAL', MEDIO: 'MOD', NORMAL: 'NORMAL', LOW: 'LOW', MOD: 'MOD', HIGH: 'HIGH' }
  return map[v?.toUpperCase()] ?? (v || '—')
}

const STATUS_BADGE = {
  NOMINAL:  'bg-green-50 border-green-200 text-green-700',
  CAUTION:  'bg-amber-50 border-amber-200 text-amber-700',
  CRITICAL: 'bg-red-50 border-red-200 text-red-600',
  'NO DATA':'bg-black/5 border-black/10 text-black/30',
}

// ─── DOCTOR: Dashboard ────────────────────────────────────────────────────────
function DoctorDashboard() {
  const [selectedMission, setSelectedMission] = useState(null)
  const [patients,        setPatients]        = useState([])
  const [logs,            setLogs]            = useState({})
  const [loading,         setLoading]         = useState(false)

  useEffect(() => {
    if (!selectedMission) return
    setLoading(true)
    supabase
      .from('user_profiles')
      .select('*')
      .eq('role', 'paciente')
      .then(async ({ data: pts }) => {
        const pList = pts ?? []
        setPatients(pList)
        const logMap = {}
        await Promise.all(pList.map(async p => {
          const { data } = await supabase
            .from('astronaut_log')
            .select('*')
            .eq('user_id', p.id)
            .order('created_at', { ascending: false })
            .limit(1)
          if (data?.[0]) logMap[p.id] = data[0]
        }))
        setLogs(logMap)
        setLoading(false)
      })
  }, [selectedMission])

  // ── Mission selection view ──
  if (!selectedMission) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-lg font-bold text-black">Mission Overview</h1>
          <p className="text-black/30 text-xs font-mono mt-0.5">Select a mission to view crew health status</p>
        </div>
        <div className="space-y-3">
          {MISSIONS.map(m => (
            <div key={m.id}
              className="bg-white border border-black/8 rounded-2xl p-5 cursor-pointer hover:border-[#6AA6DA]/40 hover:shadow-sm transition-all"
              onClick={() => setSelectedMission(m)}
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-black font-bold text-sm">{m.id}</span>
                    {m.status === 'ACTIVE' && (
                      <span className="text-[9px] font-mono px-1.5 py-0.5 rounded-full bg-green-50 border border-green-200 text-green-700">ACTIVE</span>
                    )}
                  </div>
                  <p className="text-black/40 text-xs font-mono">{m.name}</p>
                </div>
                <div className="text-right">
                  <p className="text-black/30 text-[10px] font-mono">{m.crew} crew members</p>
                  <span className="text-[#6AA6DA]/70 text-xs font-mono">View status →</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  if (loading) return (
    <div className="flex items-center justify-center h-60 text-black/20 font-mono text-sm">Loading crew data...</div>
  )

  const critical = patients.filter(p => doctorOverallStatus(logs[p.id]) === 'CRITICAL').length
  const caution  = patients.filter(p => doctorOverallStatus(logs[p.id]) === 'CAUTION').length

  // Sort: CRITICAL first, CAUTION second
  const sorted = [...patients].sort((a, b) => {
    const order = { CRITICAL: 0, CAUTION: 1, NOMINAL: 2, 'NO DATA': 3 }
    return (order[doctorOverallStatus(logs[a.id])] ?? 3) - (order[doctorOverallStatus(logs[b.id])] ?? 3)
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <button
              onClick={() => { setSelectedMission(null); setPatients([]); setLogs({}) }}
              className="text-black/30 hover:text-black/60 text-xs font-mono transition-colors"
            >
              ← Missions
            </button>
            <span className="text-black/15 text-xs">/</span>
            <span className="text-black/50 text-xs font-mono">{selectedMission.id}</span>
          </div>
          <h1 className="text-lg font-bold text-black">Crew Health Status</h1>
          <p className="text-black/30 text-xs font-mono mt-0.5">{selectedMission.name} — {patients.length} crew members</p>
        </div>
        <div className="flex gap-2 text-[10px] font-mono">
          {critical > 0 && (
            <span className="px-2 py-1 rounded-full bg-red-50 border border-red-200 text-red-600">{critical} CRITICAL</span>
          )}
          {caution > 0 && (
            <span className="px-2 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-700">{caution} CAUTION</span>
          )}
        </div>
      </div>

      {patients.length === 0 ? (
        <div className="bg-white border border-black/8 rounded-2xl p-10 text-center text-black/20 font-mono text-xs">
          No crew members registered.
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {sorted.map(p => {
            const log    = logs[p.id]
            const status = doctorOverallStatus(log)
            const badge  = STATUS_BADGE[status] ?? STATUS_BADGE.NOMINAL
            return (
              <div key={p.id} className={`bg-white border ${status === 'CRITICAL' ? 'border-red-200' : status === 'CAUTION' ? 'border-amber-200' : 'border-black/8'} rounded-2xl p-5`}>
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <p className="font-semibold text-black">{p.full_name || 'Unnamed'}</p>
                    <p className="text-black/30 text-[10px] font-mono mt-0.5">
                      {log ? `Last check: Day ${log.days_in_space}` : 'No data yet'}
                    </p>
                  </div>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${badge}`}>{status}</span>
                </div>

                {log ? (
                  <div className="space-y-2">
                    <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
                      {[
                        ['Sleep',  log.sleep_quality + '%'],
                        ['Energy', log.energy_level  + '%'],
                        ['Mood',   log.mood           + '%'],
                        ['HR',     log.heart_rate     + ' bpm'],
                      ].map(([k, v]) => (
                        <div key={k} className="flex justify-between bg-black/4 rounded-lg px-2 py-1.5">
                          <span className="text-black/30">{k}</span>
                          <span className="text-black/60 font-bold">{v}</span>
                        </div>
                      ))}
                    </div>
                    {log.prescription_plant && (
                      <p className="text-[10px] font-mono text-green-700 bg-green-50 border border-green-200 rounded-lg px-2 py-1.5">
                        Rx: {log.prescription_plant}
                      </p>
                    )}
                    {log.symptoms?.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {log.symptoms.slice(0, 3).map(s => (
                          <span key={s} className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-amber-50 border border-amber-200 text-amber-700">{s}</span>
                        ))}
                        {log.symptoms.length > 3 && (
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-black/5 text-black/30">+{log.symptoms.length - 3}</span>
                        )}
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-black/20 text-[10px] font-mono text-center py-4">Waiting for first diagnostic</p>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

// ─── DOCTOR: Patients (mission → patient → detail) ────────────────────────────
function DoctorPatients() {
  const { profile } = useAuth()
  const [view,            setView]            = useState('missions')
  const [selectedMission, setSelectedMission] = useState(null)
  const [patients,        setPatients]        = useState([])
  const [selectedPatient, setSelectedPatient] = useState(null)
  const [patientLogs,     setPatientLogs]     = useState([])
  const [patientVitals,   setPatientVitals]   = useState(null)
  const [loading,         setLoading]         = useState(false)

  async function openMission(m) {
    setSelectedMission(m)
    setView('patients')
    setLoading(true)
    const { data } = await supabase.from('user_profiles').select('*').eq('role', 'paciente')
    setPatients(data || [])
    setLoading(false)
  }

  async function openPatient(p) {
    setSelectedPatient(p)
    setView('detail')
    setLoading(true)
    try {
      const [logsRes, vitalsRes] = await Promise.all([
        supabase.from('astronaut_log').select('*').eq('user_id', p.id).order('created_at', { ascending: false }),
        supabase.from('patient_vitals').select('*').eq('patient_id', p.id).limit(1).maybeSingle(),
      ])
      setPatientLogs(logsRes.data || [])
      setPatientVitals(vitalsRes.data || null)
      if (profile?.id) {
        supabase.from('profile_views').insert({ viewer_id: profile.id, patient_id: p.id }).catch(() => {})
      }
    } finally {
      setLoading(false)
    }
  }

  // ── Level 1: Mission list ──
  if (view === 'missions') {
    return (
      <div className="space-y-5">
        <div>
          <h1 className="text-xl font-bold text-black">Patients</h1>
          <p className="text-black/30 text-xs font-mono mt-0.5">Select a mission to view its crew</p>
        </div>
        <div className="space-y-3">
          {MISSIONS.map(m => (
            <div key={m.id}
              className="bg-white border border-black/8 rounded-xl p-4 flex items-center justify-between cursor-pointer hover:border-[#6AA6DA]/30 hover:shadow-sm transition-all"
              onClick={() => openMission(m)}
            >
              <div>
                <div className="flex items-center gap-2">
                  <p className="text-black font-medium text-sm">{m.id}</p>
                  {m.status === 'ACTIVE' && (
                    <span className="text-[9px] font-mono px-1.5 py-0.5 rounded-full bg-green-50 border border-green-200 text-green-700">ACTIVE</span>
                  )}
                </div>
                <p className="text-black/30 text-[10px] font-mono">{m.name}</p>
              </div>
              <span className="text-[#6AA6DA]/70 text-xs font-mono">View patients →</span>
            </div>
          ))}
        </div>
      </div>
    )
  }

  // ── Level 2: Patient list ──
  if (view === 'patients') {
    return (
      <div className="space-y-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <button onClick={() => setView('missions')} className="text-black/30 hover:text-black/60 text-xs font-mono transition-colors">
              ← Missions
            </button>
            <span className="text-black/15 text-xs">/</span>
            <span className="text-black/50 text-xs font-mono">{selectedMission?.id}</span>
          </div>
          <h1 className="text-xl font-bold text-black">Crew — {selectedMission?.id}</h1>
          <p className="text-black/30 text-xs font-mono mt-0.5">{patients.length} patients registered</p>
        </div>
        {loading ? (
          <p className="text-black/40 font-mono text-sm">Loading...</p>
        ) : patients.length === 0 ? (
          <p className="text-black/30 text-sm">No patients registered for this mission.</p>
        ) : (
          <div className="space-y-3">
            {patients.map(p => (
              <div key={p.id}
                className="bg-white border border-black/8 rounded-xl p-4 flex items-center justify-between cursor-pointer hover:border-[#6AA6DA]/30 hover:shadow-sm transition-all"
                onClick={() => openPatient(p)}
              >
                <div>
                  <p className="text-black font-medium text-sm">{p.full_name || 'Unnamed'}</p>
                  <p className="text-black/30 text-[10px] font-mono">Registered: {new Date(p.created_at).toLocaleDateString('en-US')}</p>
                </div>
                <span className="text-[#6AA6DA]/70 text-xs font-mono">View record →</span>
              </div>
            ))}
          </div>
        )}
      </div>
    )
  }

  // ── Level 3: Patient detail ──
  if (view === 'detail') {
    if (loading) return (
      <div className="flex items-center justify-center h-60 text-black/20 font-mono text-sm">Loading patient data...</div>
    )

    return (
      <div className="space-y-5">
        {/* Breadcrumb */}
        <div>
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <button onClick={() => setView('missions')} className="text-black/30 hover:text-black/60 text-xs font-mono transition-colors">
              ← Missions
            </button>
            <span className="text-black/15 text-xs">/</span>
            <button onClick={() => setView('patients')} className="text-black/30 hover:text-black/60 text-xs font-mono transition-colors">
              {selectedMission?.id}
            </button>
            <span className="text-black/15 text-xs">/</span>
            <span className="text-black/50 text-xs font-mono">{selectedPatient?.full_name || 'Patient'}</span>
          </div>
          <h1 className="text-xl font-bold text-black">{selectedPatient?.full_name || 'Patient'}</h1>
          <p className="text-black/30 text-xs font-mono mt-0.5">Clinical record — {selectedMission?.id}</p>
        </div>

        {/* Personal Data */}
        <div className="bg-white border border-black/8 rounded-2xl p-5">
          <p className="text-black/35 text-[10px] font-mono uppercase tracking-wider mb-3">Personal Data</p>
          {patientVitals ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-[10px] font-mono">
              {[
                ['Weight',       patientVitals.weight_kg ? patientVitals.weight_kg + ' kg' : '—'],
                ['Height',       patientVitals.height_cm ? patientVitals.height_cm + ' cm' : '—'],
                ['BP Baseline',  (patientVitals.bp_systolic && patientVitals.bp_diastolic) ? patientVitals.bp_systolic + '/' + patientVitals.bp_diastolic + ' mmHg' : '—'],
                ['HR Baseline',  patientVitals.heart_rate_baseline ? patientVitals.heart_rate_baseline + ' bpm' : '—'],
                ['Blood Type',   patientVitals.blood_type || '—'],
                ['Age',          patientVitals.age ? patientVitals.age + ' yrs' : '—'],
              ].map(([k, v]) => (
                <div key={k} className="bg-black/4 rounded-lg px-3 py-2.5">
                  <p className="text-black/30 mb-1">{k}</p>
                  <p className="text-black/70 font-bold">{v}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-black/20 text-xs font-mono py-2">No pre-mission data on file.</p>
          )}
        </div>

        {/* Clinical History */}
        <div>
          <p className="text-black/35 text-[10px] font-mono uppercase tracking-wider mb-3">
            Clinical History — {patientLogs.length} {patientLogs.length === 1 ? 'entry' : 'entries'}
          </p>
          {patientLogs.length === 0 ? (
            <div className="bg-white border border-black/8 rounded-2xl p-6 text-center text-black/20 font-mono text-xs">
              No diagnostics recorded yet.
            </div>
          ) : (
            <div className="space-y-3">
              {patientLogs.map((log, i) => {
                const status = doctorOverallStatus(log)
                const badge  = STATUS_BADGE[status] ?? STATUS_BADGE.NOMINAL
                return (
                  <div key={log.id ?? i} className={`bg-white border ${status === 'CRITICAL' ? 'border-red-200' : status === 'CAUTION' ? 'border-amber-200' : 'border-black/8'} rounded-2xl p-4`}>
                    <div className="flex items-center justify-between mb-3">
                      <p className="text-black/40 text-[10px] font-mono">
                        {new Date(log.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                        {log.days_in_space ? ` · Day ${log.days_in_space}` : ''}
                      </p>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${badge}`}>{status}</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px] font-mono mb-2">
                      {[
                        ['Sleep',  log.sleep_quality + '%'],
                        ['Energy', log.energy_level  + '%'],
                        ['Mood',   log.mood           + '%'],
                        ['HR',     log.heart_rate     + ' bpm'],
                      ].map(([k, v]) => (
                        <div key={k} className="flex justify-between bg-black/4 rounded-lg px-2 py-1.5">
                          <span className="text-black/30">{k}</span>
                          <span className="text-black/60 font-bold">{v}</span>
                        </div>
                      ))}
                    </div>
                    <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-[10px] font-mono mb-2">
                      {[
                        ['Stress',       log.stress_level],
                        ['Inflammation', log.inflammation_level],
                        ['Cognitive',    log.cognitive_level],
                        ['Cardio',       log.cardiovascular_level],
                      ].filter(([, v]) => v).map(([k, v]) => (
                        <div key={k} className="flex justify-between text-black/40">
                          <span>{k}</span>
                          <span className="font-medium text-black/60">{doctorDisplayLevel(v)}</span>
                        </div>
                      ))}
                    </div>
                    {log.prescription_plant && (
                      <p className="text-[10px] font-mono text-green-700 bg-green-50 border border-green-200 rounded-lg px-2 py-1.5 mb-2">
                        Rx: {log.prescription_plant}
                      </p>
                    )}
                    {log.symptoms?.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {log.symptoms.map(s => (
                          <span key={s} className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-amber-50 border border-amber-200 text-amber-700">{s}</span>
                        ))}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>
    )
  }

  return null
}

// ─── DOCTOR: Mission Log grouped by patient ───────────────────────────────────
function DoctorMissionLog() {
  const [patients, setPatients] = useState([])
  const [logs,     setLogs]     = useState([])
  const [loading,  setLoading]  = useState(true)
  const [expanded, setExpanded] = useState(null)

  useEffect(() => {
    Promise.all([
      supabase.from('user_profiles').select('*').eq('role', 'paciente'),
      supabase.from('astronaut_log').select('*').order('created_at', { ascending: false }),
    ]).then(([{ data: pts }, { data: ls }]) => {
      setPatients(pts ?? [])
      setLogs(ls ?? [])
      setLoading(false)
    })
  }, [])

  if (loading) return (
    <div className="flex items-center justify-center h-60 text-black/20 font-mono text-sm">Loading...</div>
  )

  const patientMap = Object.fromEntries((patients).map(p => [p.id, p]))

  // Group logs by patient
  const grouped = {}
  logs.forEach(log => {
    const key = log.user_id ?? 'unknown'
    if (!grouped[key]) grouped[key] = []
    grouped[key].push(log)
  })

  function statusOf(log) {
    const levels = [log.stress_level, log.inflammation_level, log.cognitive_level, log.cardiovascular_level]
    if (levels.some(l => l === 'HIGH' || l === 'ALTO' || l === 'CRITICO')) return 'CRITICAL'
    if (levels.some(l => l === 'MOD'  || l === 'MEDIO'))                   return 'CAUTION'
    return 'NOMINAL'
  }

  const statusDot = { NOMINAL: '#6AA6DA', CAUTION: '#facc15', CRITICAL: '#f87171' }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-lg font-bold text-black">Mission Log</h1>
        <p className="text-black/30 text-xs font-mono mt-0.5">Diagnostic history by patient — {logs.length} entries total</p>
      </div>

      {Object.keys(grouped).length === 0 ? (
        <div className="bg-white border border-black/8 rounded-2xl p-10 text-center text-black/20 font-mono text-xs">
          No records yet.
        </div>
      ) : (
        Object.entries(grouped).map(([userId, userLogs]) => {
          const pt = patientMap[userId]
          const name = pt?.full_name ?? (userId === 'unknown' ? 'Unknown Patient' : `Patient ${userId.slice(0, 6)}`)
          return (
            <div key={userId}>
              <div className="flex items-center gap-2 mb-3">
                <p className="text-sm font-semibold text-black">{name}</p>
                <span className="text-black/25 text-[10px] font-mono">{userLogs.length} entries</span>
              </div>
              <div className="space-y-2 pl-2 border-l-2 border-black/8">
                {userLogs.map(log => {
                  const status = statusOf(log)
                  const dot    = statusDot[status] ?? '#6AA6DA'
                  const isOpen = expanded === log.id
                  return (
                    <div key={log.id} className="bg-white border border-black/8 rounded-xl overflow-hidden">
                      <button onClick={() => setExpanded(isOpen ? null : log.id)} className="w-full p-3 text-left">
                        <div className="flex items-center gap-3">
                          <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: dot }} />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-xs font-mono font-bold" style={{ color: dot }}>{status}</span>
                              <span className="text-black/20 text-xs font-mono">·</span>
                              <span className="text-black/40 text-xs font-mono">Day {log.days_in_space}</span>
                              {log.prescription_plant && (
                                <span className="text-green-700 text-xs font-mono truncate">{log.prescription_plant}</span>
                              )}
                            </div>
                            <p className="text-black/25 text-[10px] font-mono mt-0.5">
                              {new Date(log.created_at).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })}
                            </p>
                          </div>
                          <div className="flex gap-3 text-[10px] font-mono text-black/30 shrink-0">
                            <span>Sleep {log.sleep_quality}%</span>
                            <span>{log.heart_rate} bpm</span>
                          </div>
                          <span className="text-black/20 text-xs">{isOpen ? '▲' : '▼'}</span>
                        </div>
                      </button>
                      {isOpen && (
                        <div className="px-4 pb-4 pt-3 border-t border-black/8 grid grid-cols-2 sm:grid-cols-4 gap-2">
                          {[
                            ['Sleep',   log.sleep_quality + '%'],
                            ['Energy',  log.energy_level  + '%'],
                            ['Mood',    log.mood           + '%'],
                            ['HR',      log.heart_rate     + ' bpm'],
                          ].map(([k, v]) => (
                            <div key={k} className="bg-black/4 rounded-xl p-2.5 text-center">
                              <p className="text-black/70 font-bold font-mono text-sm">{v}</p>
                              <p className="text-black/30 text-[10px] font-mono mt-0.5">{k}</p>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            </div>
          )
        })
      )}
    </div>
  )
}

// ─── PROGRAMADOR: Dashboard ───────────────────────────────────────────────────
function ProgramadorDashboard() {
  const [stats, setStats] = useState(null)
  const [pods,  setPods]  = useState([])
  const [logs,  setLogs]  = useState([])

  useEffect(() => {
    Promise.all([
      supabase.from('user_profiles').select('*', { count: 'exact', head: true }),
      supabase.from('astronaut_log').select('*', { count: 'exact', head: true }),
      supabase.from('plants').select('*', { count: 'exact', head: true }),
      supabase.from('access_requests').select('*', { count: 'exact', head: true }),
      supabase.from('seed_cartridges').select('*, plant:plants(plant_name)').order('slot'),
      supabase.from('astronaut_log').select('*').order('created_at', { ascending: false }).limit(10),
    ]).then(([users, logs, plants, reqs, { data: podData }, { data: logData }]) => {
      setStats({ users: users.count, logs: logs.count, plants: plants.count, requests: reqs.count })
      setPods(podData ?? [])
      setLogs(logData ?? [])
    })
  }, [])

  // Detect anomalies in logs
  const anomalies = logs.filter(l =>
    l.heart_rate > 100 || l.heart_rate < 50 ||
    l.stress_level === 'ALTO' || l.stress_level === 'CRITICO' ||
    l.cardiovascular_level === 'ALTO' || l.cardiovascular_level === 'CRITICO'
  )

  function sensorSim(pod) {
    const seed = (pod.slot ?? 1) * 7 + (pod.id ?? 1) * 3
    return {
      humidity:    55 + (seed % 30),
      temperature: 22 + (seed % 8),
      waterLevel:  pod.status === 'ready' ? 85 + (seed % 10) : 40 + (seed % 40),
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-lg font-bold text-black">Engineer Dashboard</h1>
        <p className="text-black/30 text-xs font-mono mt-0.5">System status — Mission ALPHA-1</p>
      </div>

      {/* System health indicators */}
      <div>
        <p className="text-black/35 text-[10px] font-mono uppercase tracking-wider mb-3">Systems</p>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: 'Supabase DB',    ok: true  },
            { label: 'Auth Service',   ok: true  },
            { label: 'Veggie Module',  ok: pods.length > 0 },
            { label: 'Health Engine',  ok: true  },
          ].map(({ label, ok }) => (
            <div key={label} className="bg-white border border-black/8 rounded-xl p-3 flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${ok ? 'bg-green-400' : 'bg-red-400'}`} />
              <div>
                <p className="text-black/70 text-xs font-medium">{label}</p>
                <p className={`text-[10px] font-mono ${ok ? 'text-green-600' : 'text-red-500'}`}>{ok ? 'RUNNING' : 'DOWN'}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {stats ? [
          { label: 'Users',    value: stats.users,    color: '#6AA6DA'  },
          { label: 'Log Entries', value: stats.logs,  color: '#4ade80'  },
          { label: 'Plants DB',value: stats.plants,   color: '#E1E5AC'  },
          { label: 'Requests', value: stats.requests, color: '#fb923c'  },
        ].map(s => (
          <div key={s.label} className="bg-white border border-black/8 rounded-xl p-4">
            <p className="text-2xl font-bold font-mono" style={{ color: s.color }}>{s.value ?? '—'}</p>
            <p className="text-black/40 text-xs mt-1">{s.label}</p>
          </div>
        )) : (
          <p className="text-black/40 font-mono text-sm col-span-4 animate-pulse">Loading...</p>
        )}
      </div>

      {/* Plant sensor readings */}
      <div>
        <p className="text-black/35 text-[10px] font-mono uppercase tracking-wider mb-3">Plant System — Veggie Module</p>
        {pods.length === 0 ? (
          <div className="bg-white border border-black/8 rounded-xl p-6 text-center text-black/20 font-mono text-xs">No pods registered</div>
        ) : (
          <div className="bg-white border border-black/8 rounded-2xl overflow-hidden">
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="border-b border-black/8 bg-black/2">
                  {['Slot', 'Plant', 'Humidity', 'Temp', 'Water', 'Status'].map(h => (
                    <th key={h} className="text-left text-[10px] text-black/30 uppercase tracking-wider px-4 py-2.5">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {pods.map(pod => {
                  const s   = sensorSim(pod)
                  const hOk = s.humidity > 55
                  const wOk = s.waterLevel > 50
                  return (
                    <tr key={pod.id} className="border-b border-black/5 last:border-0 hover:bg-black/2">
                      <td className="px-4 py-2.5 text-black/40">{pod.slot}</td>
                      <td className="px-4 py-2.5 text-black/70">{pod.plant?.plant_name ?? '—'}</td>
                      <td className="px-4 py-2.5" style={{ color: hOk ? '#6AA6DA' : '#facc15' }}>{s.humidity}%</td>
                      <td className="px-4 py-2.5 text-black/50">{s.temperature}°C</td>
                      <td className="px-4 py-2.5" style={{ color: wOk ? '#4ade80' : '#f87171' }}>{s.waterLevel}%</td>
                      <td className="px-4 py-2.5">
                        <span className={`text-[10px] uppercase px-1.5 py-0.5 rounded ${
                          pod.status === 'ready' ? 'bg-green-50 text-green-700' : 'bg-amber-50 text-amber-700'
                        }`}>{pod.status}</span>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Anomalies */}
      <div>
        <p className="text-black/35 text-[10px] font-mono uppercase tracking-wider mb-3">
          Detected Anomalies <span className="text-black/20">({anomalies.length})</span>
        </p>
        {anomalies.length === 0 ? (
          <div className="bg-white border border-black/8 rounded-xl p-6 text-center text-black/20 font-mono text-xs">
            No anomalies in recent logs
          </div>
        ) : (
          <div className="space-y-2">
            {anomalies.slice(0, 5).map(log => (
              <div key={log.id} className="bg-red-50 border border-red-200 rounded-xl p-3 flex items-start gap-3">
                <div className="w-1.5 h-1.5 rounded-full bg-red-400 mt-1.5 shrink-0" />
                <div className="flex-1 min-w-0 text-xs font-mono">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-red-700 font-bold">Day {log.days_in_space}</span>
                    {log.heart_rate > 100 && <span className="text-red-600">HR {log.heart_rate} bpm (high)</span>}
                    {log.heart_rate < 50  && <span className="text-red-600">HR {log.heart_rate} bpm (low)</span>}
                    {(log.stress_level === 'ALTO' || log.stress_level === 'CRITICO') && <span className="text-red-600">Stress {log.stress_level}</span>}
                    {(log.cardiovascular_level === 'ALTO' || log.cardiovascular_level === 'CRITICO') && <span className="text-red-600">Cardio {log.cardiovascular_level}</span>}
                  </div>
                  <p className="text-black/30 text-[10px] mt-0.5">
                    {new Date(log.created_at).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Patient: profile view history ───────────────────────────────────────────
function PatientProfileViews() {
  const { user } = useAuth()
  const [views,   setViews]   = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    supabase
      .from('profile_views')
      .select(`id, created_at, viewer:user_profiles!profile_views_viewer_id_fkey(full_name, role)`)
      .eq('patient_id', user.id)
      .order('created_at', { ascending: false })
      .then(({ data }) => { setViews(data || []); setLoading(false) })
  }, [user.id])

  return (
    <div className="mt-8">
      <h2 className="text-base font-semibold text-black mb-4">Who viewed your profile</h2>
      {loading ? (
        <p className="text-black/40 font-mono text-sm">Loading...</p>
      ) : views.length === 0 ? (
        <p className="text-black/30 text-sm">Nobody has viewed your profile yet.</p>
      ) : (
        <div className="space-y-2">
          {views.map(v => (
            <div key={v.id} className="bg-white border border-black/8 rounded-xl p-3 flex items-center justify-between">
              <div>
                <p className="text-black/70 text-sm">{v.viewer?.full_name || 'Unknown'}</p>
                <p className="text-green-700 text-[10px] font-mono uppercase">
                  {{ paciente: 'Patient', doctor: 'Doctor', programador: 'Engineer', admin: 'Admin' }[v.viewer?.role] ?? v.viewer?.role}
                </p>
              </div>
              <p className="text-black/20 text-[10px] font-mono">
                {new Date(v.created_at).toLocaleString('en-US')}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ─── Patient dashboard wrapper ────────────────────────────────────────────────
function PatientDashboard() {
  return (
    <>
      <Dashboard />
      <PatientProfileViews />
    </>
  )
}

// ─── App principal ────────────────────────────────────────────────────────────
function AppRoutes() {
  const { user, profile, loading } = useAuth()

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#FBFBF8]">
        <div className="text-[#6AA6DA] font-mono text-sm animate-pulse">Initializing E.D.E.N. systems...</div>
      </div>
    )
  }

  const role = profile?.role

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <Login />} />

      {/* Dashboard — different view per role */}
      <Route path="/" element={
        <ProtectedRoute>
          <Layout>
            {role === 'paciente'    ? <PatientDashboard />    :
             role === 'doctor'      ? <DoctorDashboard />     :
             role === 'programador' ? <ProgramadorDashboard /> :
             role === 'admin'       ? <AdminDashboard />       :
             <Dashboard />}
          </Layout>
        </ProtectedRoute>
      } />

      {/* Settings — all roles */}
      <Route path="/settings" element={
        <ProtectedRoute>
          <Layout><Settings /></Layout>
        </ProtectedRoute>
      } />

      {/* Shared: Health Check */}
      <Route path="/health" element={
        <ProtectedRoute allowedRoles={['paciente','doctor','programador']}>
          <Layout><HealthCheck /></Layout>
        </ProtectedRoute>
      } />

      {/* Shared: Plant Monitor / Plant Log */}
      <Route path="/plants" element={
        <ProtectedRoute>
          <Layout><PlantMonitor /></Layout>
        </ProtectedRoute>
      } />
      <Route path="/plantlog" element={
        <ProtectedRoute allowedRoles={['doctor']}>
          <Layout><PlantMonitor /></Layout>
        </ProtectedRoute>
      } />

      {/* Mission Log — different view per role */}
      <Route path="/log" element={
        <ProtectedRoute allowedRoles={['paciente','programador','doctor']}>
          <Layout>
            {role === 'doctor' ? <DoctorMissionLog /> : <MissionLog />}
          </Layout>
        </ProtectedRoute>
      } />

      {/* Doctor: Patients */}
      <Route path="/patients" element={
        <ProtectedRoute allowedRoles={['doctor']}>
          <Layout><DoctorPatients /></Layout>
        </ProtectedRoute>
      } />

      {/* Engineer routes */}
      <Route path="/system" element={
        <ProtectedRoute allowedRoles={['programador','admin']}>
          <Layout><ProgramadorDashboard /></Layout>
        </ProtectedRoute>
      } />

      {/* Admin routes */}
      <Route path="/requests" element={
        <ProtectedRoute allowedRoles={['admin','programador']}>
          <Layout><AdminRequests /></Layout>
        </ProtectedRoute>
      } />
      <Route path="/users" element={
        <ProtectedRoute allowedRoles={['admin','programador']}>
          <Layout><AdminUsers /></Layout>
        </ProtectedRoute>
      } />

      {/* Catch-all */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  )
}
