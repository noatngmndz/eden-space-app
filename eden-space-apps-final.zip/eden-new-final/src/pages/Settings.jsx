import { useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../App'

const ROLE_LABEL = {
  paciente:    'Patient',
  doctor:      'Doctor',
  programador: 'Engineer',
  admin:       'Administrator',
}

const ROLE_COLOR = {
  paciente:    '#6AA6DA',
  doctor:      '#4ade80',
  programador: '#E1E5AC',
  admin:       '#fb923c',
}

function AvatarCircle({ name, role, size = 'lg' }) {
  const initials = (name || '?').split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()
  const color    = ROLE_COLOR[role] ?? '#6AA6DA'
  const cls      = size === 'lg' ? 'w-20 h-20 text-2xl' : 'w-10 h-10 text-sm'
  return (
    <div className={`${cls} rounded-full flex items-center justify-center font-bold font-mono border-2`}
      style={{ backgroundColor: color + '20', borderColor: color + '40', color }}>
      {initials}
    </div>
  )
}

export default function Settings() {
  const { user, profile } = useAuth()
  const [form, setForm] = useState({
    full_name:  profile?.full_name  ?? '',
    bio:        profile?.bio        ?? '',
    specialty:  profile?.specialty  ?? '',
    mission:    profile?.mission    ?? '',
  })
  const [saving,  setSaving]  = useState(false)
  const [saved,   setSaved]   = useState(false)
  const [error,   setError]   = useState(null)

  if (!profile) return (
    <div className="flex items-center justify-center h-60 text-black/20 font-mono text-sm">
      Loading profile...
    </div>
  )

  async function handleSave(e) {
    e.preventDefault()
    setSaving(true)
    setSaved(false)
    setError(null)

    const updates = { full_name: form.full_name.trim() }
    if (form.bio.trim())       updates.bio       = form.bio.trim()
    if (form.specialty.trim()) updates.specialty  = form.specialty.trim()
    if (form.mission.trim())   updates.mission    = form.mission.trim()

    const { error: err } = await supabase
      .from('user_profiles')
      .update(updates)
      .eq('id', user.id)

    setSaving(false)
    if (err) setError(err.message)
    else     setSaved(true)
  }

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <div>
        <h1 className="text-lg font-bold text-black">Profile Settings</h1>
        <p className="text-black/30 text-xs font-mono mt-0.5">Edit your personal information</p>
      </div>

      {/* Avatar + role */}
      <div className="bg-white border border-black/8 rounded-2xl p-6 flex items-center gap-5">
        <AvatarCircle name={form.full_name || profile.full_name} role={profile.role} />
        <div>
          <p className="font-bold text-black">{profile.full_name || '—'}</p>
          <p className="text-xs font-mono mt-0.5" style={{ color: ROLE_COLOR[profile.role] ?? '#6AA6DA' }}>
            {ROLE_LABEL[profile.role] ?? profile.role}
          </p>
          <p className="text-black/25 text-[10px] font-mono mt-0.5">{user?.email}</p>
        </div>
      </div>

      {/* Edit form */}
      <form onSubmit={handleSave} className="bg-white border border-black/8 rounded-2xl p-6 space-y-4">
        <Field label="Full Name" value={form.full_name} onChange={v => setForm(f => ({ ...f, full_name: v }))} placeholder="Your full name" />

        {profile.role === 'doctor' && (
          <Field label="Specialty" value={form.specialty} onChange={v => setForm(f => ({ ...f, specialty: v }))} placeholder="e.g. Space medicine, Cardiology" />
        )}

        {(profile.role === 'paciente' || profile.role === 'programador') && (
          <Field label="Mission ID" value={form.mission} onChange={v => setForm(f => ({ ...f, mission: v }))} placeholder="e.g. ALPHA-1" />
        )}

        <div>
          <label className="block text-black/40 text-[10px] font-mono uppercase tracking-wider mb-1.5">Bio</label>
          <textarea
            value={form.bio}
            onChange={e => setForm(f => ({ ...f, bio: e.target.value }))}
            rows={3}
            placeholder="Short description..."
            className="w-full bg-[#FBFBF8] border border-black/10 rounded-xl px-4 py-2.5 text-xs font-mono text-black/70 placeholder-black/20 focus:outline-none focus:border-[#6AA6DA]/40 resize-none"
          />
        </div>

        {error && (
          <p className="text-red-500 text-xs font-mono">{error}</p>
        )}

        <button type="submit" disabled={saving}
          className="w-full bg-[#6AA6DA] hover:bg-[#5a96ca] disabled:opacity-40 text-white font-bold py-3 rounded-xl transition-all text-sm">
          {saving ? 'Saving...' : 'Save Changes'}
        </button>

        {saved && (
          <p className="text-center text-[#4ade80] font-mono text-xs">Profile updated successfully.</p>
        )}
      </form>

      {/* Read-only info */}
      <div className="bg-white border border-black/8 rounded-2xl p-5 space-y-3">
        <p className="text-black/35 text-[10px] font-mono uppercase tracking-wider">Account Info</p>
        {[
          ['Email',   user?.email ?? '—'],
          ['Role',    ROLE_LABEL[profile.role] ?? profile.role],
          ['User ID', user?.id?.slice(0, 8) + '…'],
        ].map(([k, v]) => (
          <div key={k} className="flex justify-between text-xs font-mono">
            <span className="text-black/30">{k}</span>
            <span className="text-black/60">{v}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

function Field({ label, value, onChange, placeholder }) {
  return (
    <div>
      <label className="block text-black/40 text-[10px] font-mono uppercase tracking-wider mb-1.5">{label}</label>
      <input
        type="text"
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-[#FBFBF8] border border-black/10 rounded-xl px-4 py-2.5 text-xs font-mono text-black/70 placeholder-black/20 focus:outline-none focus:border-[#6AA6DA]/40"
      />
    </div>
  )
}
