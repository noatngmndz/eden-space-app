import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

function normStatus(raw) {
  const r = (raw ?? '').toLowerCase().trim()
  if (['ready', 'lista', 'listo', 'si', 'si', 'yes', 'active', 'activo'].includes(r)) return 'ready'
  if (['growing', 'creciendo', 'baja', 'low'].includes(r)) return 'growing'
  if (['empty', 'vacio', 'vacio', 'no', 'inactive'].includes(r)) return 'empty'
  return raw || 'unknown'
}

function growPhase(days) {
  if (days <= 30)  return { label: 'Ready',       color: '#4ade80', bg: 'bg-green-50',    border: 'border-green-200',     text: 'text-green-700'  }
  if (days <= 60)  return { label: 'Growing',     color: '#f59e0b', bg: 'bg-amber-50',    border: 'border-amber-200',     text: 'text-amber-700'  }
  return           { label: 'Early Stage',         color: '#6AA6DA', bg: 'bg-[#6AA6DA]/8', border: 'border-[#6AA6DA]/25', text: 'text-[#4a86ba]' }
}

// Simulated sensor readings derived from plant slot + status
function sensorData(pod) {
  const seed = (pod.slot ?? 1) * 7 + (pod.id ?? 1) * 3
  const humidity    = 55 + (seed % 30)
  const temperature = 22 + (seed % 8)
  const ns = normStatus(pod.status)
  const waterLevel  = ns === 'ready' ? 85 + (seed % 10) : 40 + (seed % 40)
  const lightHours  = 14 + (seed % 6)
  return { humidity, temperature, waterLevel, lightHours }
}

function SensorBar({ label, value, max, unit, color }) {
  return (
    <div>
      <div className="flex justify-between text-[10px] font-mono text-black/30 mb-1">
        <span>{label}</span>
        <span style={{ color }}>{value}{unit}</span>
      </div>
      <div className="h-1 bg-black/8 rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all"
          style={{ width: `${Math.min(100, (value / max) * 100)}%`, backgroundColor: color }} />
      </div>
    </div>
  )
}

export default function PlantMonitor() {
  const [plants,   setPlants]   = useState([])
  const [pods,     setPods]     = useState([])
  const [loading,  setLoading]  = useState(true)
  const [search,   setSearch]   = useState('')
  const [selected, setSelected] = useState(null)
  const [tab,      setTab]      = useState('plants')

  useEffect(() => {
    Promise.all([
      supabase.from('plants').select('*').order('grow_time_days'),
      supabase.from('seed_cartridges').select('*, plant:plants(plant_name, latin_name, condition, dose, grow_time_days)').order('slot'),
    ]).then(([{ data: p }, { data: sc }]) => {
      setPlants(p ?? [])
      setPods(sc ?? [])
      setLoading(false)
    })
  }, [])

  const filtered = plants.filter(p =>
    p.plant_name?.toLowerCase().includes(search.toLowerCase()) ||
    p.condition?.toLowerCase().includes(search.toLowerCase()) ||
    p.effect?.toLowerCase().includes(search.toLowerCase())
  )

  // Build condition groups for summary
  const conditionGroups = plants.reduce((acc, p) => {
    const key = p.condition || 'Other'
    acc[key] = (acc[key] || 0) + 1
    return acc
  }, {})
  const conditionEntries = Object.entries(conditionGroups).sort((a, b) => b[1] - a[1])

  if (loading) return (
    <div className="flex items-center justify-center h-40 text-black/20 font-mono text-xs">Loading...</div>
  )

  return (
    <div className="space-y-5">
      {/* Header + tabs */}
      <div className="flex flex-col sm:flex-row sm:items-end gap-3 justify-between">
        <div>
          <h1 className="text-lg font-bold text-black">Plant Monitor</h1>
          <p className="text-black/30 text-xs font-mono mt-0.5">Veggie module — onboard medicinal plants</p>
        </div>
        <div className="flex items-center gap-2">
          {['plants', 'sensors'].map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all border ${
                tab === t
                  ? 'bg-[#6AA6DA]/15 text-[#6AA6DA] border-[#6AA6DA]/30'
                  : 'bg-white border-black/10 text-black/40 hover:text-black/60'
              }`}>
              {t === 'plants' ? 'Plant Catalog' : 'Live Sensors'}
            </button>
          ))}
        </div>
      </div>

      {tab === 'plants' && (
        <>
          {/* Summary — at top */}
          <div className="bg-white border border-black/8 rounded-2xl p-4 space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-black/35 text-[10px] font-mono uppercase tracking-wider">Summary</p>
              <p className="text-black/25 text-[10px] font-mono">{plants.length} plants total</p>
            </div>

            {/* Growth phase counts */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: 'Ready (<=30d)',   count: plants.filter(p => p.grow_time_days <= 30).length,                          color: '#4ade80' },
                { label: 'Growing (<=60d)', count: plants.filter(p => p.grow_time_days > 30 && p.grow_time_days <= 60).length,  color: '#f59e0b' },
                { label: 'Long Cycle',      count: plants.filter(p => p.grow_time_days > 60).length,                            color: '#6AA6DA' },
              ].map(({ label, count, color }) => (
                <div key={label} className="text-center bg-black/3 rounded-xl p-2.5">
                  <p className="text-2xl font-bold font-mono" style={{ color }}>{count}</p>
                  <p className="text-black/30 text-[10px] font-mono mt-0.5">{label}</p>
                </div>
              ))}
            </div>

            {/* Count by condition / treated ailment */}
            {conditionEntries.length > 0 && (
              <div>
                <p className="text-black/25 text-[10px] font-mono uppercase tracking-wider mb-2">By Condition Treated</p>
                <div className="flex flex-wrap gap-1.5">
                  {conditionEntries.map(([cond, count]) => (
                    <span key={cond} className="flex items-center gap-1 px-2 py-1 rounded-lg bg-[#6AA6DA]/8 border border-[#6AA6DA]/20 text-[10px] font-mono text-[#4a86ba]">
                      <span className="font-bold">{count}</span>
                      <span className="text-black/40">{cond}</span>
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Search */}
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search by name, condition, or effect..."
            className="w-full bg-white border border-black/10 rounded-xl px-4 py-2.5 text-xs text-black placeholder-black/25 focus:outline-none focus:border-[#6AA6DA]/40 font-mono"
          />

          {filtered.length === 0 ? (
            <div className="flex items-center justify-center h-40 text-black/20 font-mono text-xs">No plants found.</div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {filtered.map(p => {
                const ph  = growPhase(p.grow_time_days)
                const pct = Math.min(100, Math.round((30 / p.grow_time_days) * 100))
                const open = selected?.id === p.id
                return (
                  <button key={p.id} onClick={() => setSelected(open ? null : p)}
                    className={`${ph.bg} border ${open ? 'border-[#6AA6DA]/40' : ph.border} rounded-2xl p-4 text-left transition-all`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <p className="text-black/80 font-medium text-sm">{p.plant_name}</p>
                        <p className="text-black/40 text-[10px] font-mono mt-0.5 italic">{p.latin_name ?? ''}</p>
                        <p className="text-black/50 text-[10px] font-mono mt-0.5">{p.condition}</p>
                      </div>
                      <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${ph.text} ${ph.border} ${ph.bg}`}>
                        {ph.label}
                      </span>
                    </div>

                    <div className="mb-3">
                      <div className="flex justify-between text-[10px] font-mono text-black/30 mb-1">
                        <span>Grow time</span>
                        <span>{p.grow_time_days} days</span>
                      </div>
                      <div className="h-1 bg-black/8 rounded-full overflow-hidden">
                        <div className="h-full rounded-full transition-all"
                          style={{ width: `${pct}%`, backgroundColor: ph.color }} />
                      </div>
                    </div>

                    <div className="flex gap-2 text-[10px] font-mono text-black/40">
                      <span className="bg-black/5 px-2 py-1 rounded-lg">{p.active_compound}</span>
                      <span className="bg-black/5 px-2 py-1 rounded-lg flex-1 truncate">{p.effect}</span>
                    </div>

                    {open && (
                      <div className="mt-4 pt-4 border-t border-black/8 space-y-1.5 text-[11px] font-mono">
                        {[
                          ['Dose',            p.dose],
                          ['Active Compound',  p.active_compound],
                          ['Effect',          p.effect],
                          ['Grow Time',       `${p.grow_time_days} days`],
                          ['NASA Backed',     p.nasa_backed ? 'Yes' : 'No'],
                        ].map(([k, v]) => (
                          <div key={k} className="flex justify-between gap-3">
                            <span className="text-black/30">{k}</span>
                            <span className="text-black/60 text-right">{v}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </button>
                )
              })}
            </div>
          )}
        </>
      )}

      {tab === 'sensors' && (
        <>
          {/* Live sensors header */}
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-black/30 text-[10px] font-mono uppercase tracking-wider">Live readings — Veggie Module</span>
          </div>

          {pods.length === 0 ? (
            <div className="flex items-center justify-center h-40 text-black/20 font-mono text-xs">No seed cartridges registered.</div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {pods.map(pod => {
                const s     = sensorData(pod)
                const ns    = normStatus(pod.status)
                const isOk  = ns === 'ready'
                const accent = isOk ? '#4ade80' : ns === 'growing' ? '#f59e0b' : '#6AA6DA'
                const statusLabel = ns.charAt(0).toUpperCase() + ns.slice(1)
                return (
                  <div key={pod.id} className="bg-white border border-black/8 rounded-2xl p-4">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <p className="text-black/70 font-medium text-sm">{pod.plant?.plant_name ?? 'Empty slot'}</p>
                        <p className="text-black/30 text-[10px] font-mono italic">{pod.plant?.latin_name ?? ''}</p>
                        <p className="text-black/25 text-[10px] font-mono mt-0.5">SLOT {pod.slot} · {pod.pod_id ?? `POD-${pod.id}`}</p>
                      </div>
                      <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full border"
                        style={{ color: accent, borderColor: accent + '40', backgroundColor: accent + '15' }}>
                        {statusLabel}
                      </span>
                    </div>

                    <div className="space-y-3">
                      <SensorBar label="Humidity"      value={s.humidity}    max={100} unit="%" color={s.humidity > 70 ? '#6AA6DA' : '#facc15'} />
                      <SensorBar label="Temperature"   value={s.temperature} max={40}  unit="°C" color={s.temperature < 28 ? '#4ade80' : '#f87171'} />
                      <SensorBar label="Water Level"   value={s.waterLevel}  max={100} unit="%" color={s.waterLevel > 60 ? '#4ade80' : '#f87171'} />
                      <SensorBar label="Light (h/day)" value={s.lightHours}  max={24}  unit="h" color="#E1E5AC" />
                    </div>

                    {pod.plant && (
                      <div className="mt-3 pt-3 border-t border-black/5 flex justify-between text-[10px] font-mono text-black/30">
                        <span>Condition: {pod.plant.condition}</span>
                        <span>{pod.plant.grow_time_days}d cycle</span>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          )}

          {/* Environment summary */}
          <div className="bg-white border border-black/8 rounded-2xl p-4">
            <p className="text-black/35 text-[10px] font-mono uppercase tracking-wider mb-3">Module Environment</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { label: 'Avg Humidity', value: '72%',       color: '#6AA6DA' },
                { label: 'Cabin Temp',   value: '24°C',      color: '#4ade80' },
                { label: 'CO2 Level',    value: '0.04%',     color: '#4ade80' },
                { label: 'Active Pods',  value: pods.length, color: '#E1E5AC' },
              ].map(({ label, value, color }) => (
                <div key={label} className="text-center">
                  <p className="text-xl font-bold font-mono" style={{ color }}>{value}</p>
                  <p className="text-black/30 text-[10px] font-mono mt-0.5">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  )
}
