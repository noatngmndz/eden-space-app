import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { analyzeHealth } from '../lib/rulesEngine'
import { useAuth } from '../App'
import {
  BarChart, Bar, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts'

const EMPTY = {
  sleep_quality: 70, energy_level: 70, mood: 70, heart_rate: 72,
  days_in_space: 0, symptoms: [],
}

const GREEN  = '#4ade80'
const YELLOW = '#facc15'
const RED    = '#f87171'
const CYAN   = '#6AA6DA'

function scoreColor(val) {
  if (val >= 70) return GREEN
  if (val >= 40) return YELLOW
  return RED
}

function StatusBadge({ status }) {
  const map = { NOMINAL: GREEN, CAUTION: YELLOW, CRITICAL: RED }
  const c = map[status] ?? CYAN
  return (
    <span style={{ color: c, borderColor: c + '40', backgroundColor: c + '15' }}
      className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border">
      {status}
    </span>
  )
}

export default function Dashboard() {
  const { user } = useAuth()
  const [log,     setLog]     = useState(null)
  const [plants,  setPlants]  = useState([])
  const [vitals,  setVitals]  = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchAll = async () => {
      const [{ data: logData }, { data: plantData }] = await Promise.all([
        supabase.from('astronaut_log').select('*').order('created_at', { ascending: false }).limit(1),
        supabase.from('plants').select('*').order('grow_time_days'),
      ])
      setLog(logData?.[0] ?? null)
      setPlants(plantData ?? [])

      if (user?.id) {
        const { data: vitalsData } = await supabase
          .from('patient_vitals')
          .select('*')
          .eq('patient_id', user.id)
          .limit(1)
          .maybeSingle()
        setVitals(vitalsData ?? null)
      }

      setLoading(false)
    }
    fetchAll()
  }, [user?.id])

  const data   = log ?? EMPTY
  const result = analyzeHealth(data)

  // Values are stored on 0-100 scale
  const barData = [
    { name: 'Sleep',  value: data.sleep_quality,                                fill: scoreColor(data.sleep_quality) },
    { name: 'Energy', value: data.energy_level,                                 fill: scoreColor(data.energy_level) },
    { name: 'Mood',   value: data.mood,                                         fill: scoreColor(data.mood) },
    { name: 'HR',     value: Math.round(((150 - data.heart_rate) / 110) * 100), fill: scoreColor(Math.round(((150 - data.heart_rate) / 110) * 100)) },
  ]

  if (loading) return (
    <div className="flex items-center justify-center h-60 text-black/20 font-mono text-sm">
      Loading...
    </div>
  )

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-black">Mission Overview</h1>
          <p className="text-black/30 text-xs font-mono mt-0.5">
            {log ? `Last check: Day ${data.days_in_space}` : 'No diagnostics yet — run a Health Check'}
          </p>
        </div>
        <StatusBadge status={result.overall} />
      </div>

      {/* Personal Data */}
      <div className="bg-white border border-black/8 rounded-2xl p-5">
        <p className="text-black/40 text-xs font-mono uppercase tracking-wider mb-3">Personal Data</p>
        {vitals ? (
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
            {[
              ['Blood Type', vitals.blood_type || '—'],
              ['Weight',     vitals.weight_kg     ? vitals.weight_kg + ' kg'                                       : '—'],
              ['Height',     vitals.height_cm     ? vitals.height_cm + ' cm'                                       : '—'],
              ['HR Base',    vitals.heart_rate_baseline ? vitals.heart_rate_baseline + ' bpm'                      : '—'],
              ['BP',         (vitals.bp_systolic && vitals.bp_diastolic) ? vitals.bp_systolic + '/' + vitals.bp_diastolic + ' mmHg' : '—'],
              ['Age',        vitals.age           ? vitals.age + ' yrs'                                            : '—'],
            ].map(([k, v]) => (
              <div key={k} className="text-center bg-black/3 rounded-xl p-2.5">
                <p className="text-black/70 font-bold font-mono text-sm">{v}</p>
                <p className="text-black/30 text-[10px] font-mono mt-0.5">{k}</p>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-black/25 text-xs font-mono py-1">
            No pre-mission physical data on file. Contact your doctor to register your baseline vitals.
          </p>
        )}
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-3 gap-3">
        <StatCard label="Status"        value={result.overall}              sub="overall"       accent={result.overall === 'NOMINAL' ? GREEN : result.overall === 'CAUTION' ? YELLOW : RED} />
        <StatCard label="Days in Space" value={data.days_in_space || '—'}  sub="mission day"   accent={CYAN} />
        <StatCard label="Alerts"        value={result.alerts.length}        sub="active alerts" accent={result.alerts.length === 0 ? GREEN : result.alerts.length <= 2 ? YELLOW : RED} />
      </div>

      {/* Biometric bar chart */}
      <div className="bg-white border border-black/8 rounded-2xl p-5">
        <p className="text-black/40 text-xs font-mono uppercase tracking-wider mb-4">Biometric Score</p>
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={barData} barSize={32}>
            <CartesianGrid strokeDasharray="3 3" stroke="#00000008" vertical={false} />
            <XAxis dataKey="name" tick={{ fill: '#00000040', fontSize: 11, fontFamily: 'monospace' }} axisLine={false} tickLine={false} />
            <YAxis domain={[0, 100]} tick={{ fill: '#00000025', fontSize: 10, fontFamily: 'monospace' }} axisLine={false} tickLine={false} />
            <Tooltip
              contentStyle={{ background: '#FBFBF8', border: '1px solid #00000015', borderRadius: 8, fontSize: 11, fontFamily: 'monospace' }}
              labelStyle={{ color: '#00000060' }}
              itemStyle={{ color: GREEN }}
              formatter={v => [`${v}%`]}
            />
            <Bar dataKey="value" radius={[4, 4, 0, 0]} opacity={0.9}>
              {barData.map((entry, index) => (
                <Cell key={index} fill={entry.fill} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Alerts */}
      <div className="bg-white border border-black/8 rounded-2xl p-5">
        <p className="text-black/40 text-xs font-mono uppercase tracking-wider mb-3">Active Alerts</p>
        {result.alerts.length === 0 ? (
          <div className="flex items-center justify-center h-16 text-black/20 font-mono text-xs">
            No active alerts
          </div>
        ) : (
          <div className="space-y-2">
            {result.alerts.map((a, i) => (
              <div key={i} className={`flex gap-3 items-start p-3 rounded-xl text-xs font-mono ${
                a.type === 'danger'
                  ? 'bg-red-50 border border-red-200 text-red-700'
                  : 'bg-amber-50 border border-amber-200 text-amber-700'
              }`}>
                <span className="shrink-0 font-bold text-[10px] opacity-60 mt-0.5">{a.system}</span>
                <span className="text-black/60">{a.msg}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Prescribed Plants */}
      {result.prescriptions.length > 0 && (
        <div className="bg-white border border-black/8 rounded-2xl p-5">
          <p className="text-black/40 text-xs font-mono uppercase tracking-wider mb-3">Prescribed Plants</p>
          <div className="space-y-2">
            {result.prescriptions.map((name, i) => {
              const plant = plants.find(p => p.plant_name?.toLowerCase().includes(name.toLowerCase()))
              return (
                <div key={i} className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-xl">
                  <div>
                    <p className="text-black/80 text-xs font-medium">{plant?.plant_name ?? name}</p>
                    <p className="text-black/40 text-[10px] font-mono mt-0.5">{plant?.condition ?? '—'}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-green-700 text-[10px] font-mono">{plant?.dose ?? '—'}</p>
                    <p className="text-black/30 text-[10px] font-mono">{plant?.grow_time_days ?? '—'}d grow</p>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}

function StatCard({ label, value, sub, accent }) {
  return (
    <div className="bg-white border border-black/8 rounded-2xl p-4">
      <p className="text-black/30 text-[10px] font-mono uppercase tracking-wider">{label}</p>
      <p className="text-2xl font-bold font-mono mt-1" style={{ color: accent }}>{value}</p>
      <p className="text-black/25 text-[10px] font-mono mt-0.5">{sub}</p>
    </div>
  )
}
