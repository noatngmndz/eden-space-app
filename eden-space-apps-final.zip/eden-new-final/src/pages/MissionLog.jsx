import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

function overallStatus(row) {
  const levels = [row.stress_level, row.inflammation_level, row.cognitive_level, row.cardiovascular_level]
  if (levels.some(l => l === 'HIGH' || l === 'ALTO' || l === 'CRITICO')) return 'CRITICAL'
  if (levels.some(l => l === 'MOD'  || l === 'MEDIO'))                    return 'CAUTION'
  return 'NOMINAL'
}

function displayLevel(v) {
  const map = { ALTO: 'HIGH', CRITICO: 'CRITICAL', MEDIO: 'MOD', NORMAL: 'NORMAL', LOW: 'LOW', MOD: 'MOD', HIGH: 'HIGH' }
  return map[v?.toUpperCase()] ?? (v || '—')
}

const STATUS = {
  NOMINAL:  { dot: '#6AA6DA', bg: 'bg-[#6AA6DA]/8',  border: 'border-[#6AA6DA]/25',  text: 'text-[#4a86ba]'  },
  CAUTION:  { dot: '#facc15', bg: 'bg-amber-50',      border: 'border-amber-200',      text: 'text-amber-700'  },
  CRITICAL: { dot: '#f87171', bg: 'bg-red-50',        border: 'border-red-200',        text: 'text-red-600'    },
}

function fmt(ts) {
  const d = new Date(ts)
  return d.toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' }) +
    ' ' + d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
}

export default function MissionLog() {
  const [logs,     setLogs]     = useState([])
  const [loading,  setLoading]  = useState(true)
  const [expanded, setExpanded] = useState(null)

  useEffect(() => {
    supabase.from('astronaut_log').select('*').order('created_at', { ascending: false }).then(({ data, error }) => {
      if (!error && data) setLogs(data)
      setLoading(false)
    })
  }, [])

  if (loading) return (
    <div className="flex items-center justify-center h-60 text-black/20 font-mono text-xs">Loading...</div>
  )

  return (
    <div className="space-y-5">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-lg font-bold text-black">Mission Log</h1>
          <p className="text-black/30 text-xs font-mono mt-0.5">E.D.E.N. diagnostic history</p>
        </div>
        <span className="text-black/25 font-mono text-xs">{logs.length} entries</span>
      </div>

      {logs.length === 0 ? (
        <div className="bg-white border border-black/8 rounded-2xl p-10 flex flex-col items-center gap-3">
          <p className="text-black/20 font-mono text-xs text-center">
            No records yet.<br />Run a Health Check to save data.
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {logs.map(log => {
            const status = overallStatus(log)
            const c      = STATUS[status] ?? STATUS.NOMINAL
            const isOpen = expanded === log.id
            return (
              <div key={log.id} className={`${c.bg} border ${c.border} rounded-2xl overflow-hidden transition-all`}>
                <button onClick={() => setExpanded(isOpen ? null : log.id)} className="w-full p-4 text-left">
                  <div className="flex items-center gap-3">
                    <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: c.dot }} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`text-xs font-mono font-bold ${c.text}`}>{status}</span>
                        <span className="text-black/20 text-xs font-mono">·</span>
                        <span className="text-black/40 text-xs font-mono">Day {log.days_in_space}</span>
                        {log.prescription_plant && (
                          <>
                            <span className="text-black/20 text-xs font-mono">·</span>
                            <span className="text-green-700 text-xs font-mono truncate">{log.prescription_plant}</span>
                          </>
                        )}
                      </div>
                      <p className="text-black/25 text-[10px] font-mono mt-0.5">{fmt(log.created_at)}</p>
                    </div>
                    <div className="flex gap-3 text-[10px] font-mono text-black/30 shrink-0">
                      <span>Sleep {log.sleep_quality}%</span>
                      <span>{log.heart_rate} bpm</span>
                    </div>
                    <span className="text-black/20 text-xs ml-1">{isOpen ? '▲' : '▼'}</span>
                  </div>
                </button>

                {isOpen && (
                  <div className="px-4 pb-4 space-y-4 border-t border-black/8 pt-4">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {[
                        ['Sleep',      log.sleep_quality + '%'],
                        ['Energy',     log.energy_level  + '%'],
                        ['Mood',       log.mood          + '%'],
                        ['Heart Rate', log.heart_rate    + ' bpm'],
                      ].map(([label, val]) => (
                        <div key={label} className="bg-black/4 rounded-xl p-3 text-center">
                          <p className="text-black/70 font-bold font-mono text-sm">{val}</p>
                          <p className="text-black/30 text-[10px] font-mono mt-0.5">{label}</p>
                        </div>
                      ))}
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        ['Stress',       log.stress_level        ],
                        ['Inflammation', log.inflammation_level  ],
                        ['Cognitive',    log.cognitive_level     ],
                        ['Cardio',       log.cardiovascular_level],
                      ].map(([k, v]) => (
                        <div key={k} className="bg-black/4 rounded-xl p-2.5 text-center">
                          <p className={`font-mono font-bold text-xs ${
                            ['HIGH','ALTO','CRITICO','CRITICAL'].includes(v?.toUpperCase()) ? 'text-red-500' :
                            ['MOD','MEDIO'].includes(v?.toUpperCase()) ? 'text-amber-600' : 'text-[#6AA6DA]'
                          }`}>{displayLevel(v)}</p>
                          <p className="text-black/30 text-[10px] font-mono mt-0.5">{k}</p>
                        </div>
                      ))}
                    </div>

                    {log.symptoms?.length > 0 && (
                      <div>
                        <p className="text-black/30 text-[10px] font-mono uppercase tracking-wider mb-2">Symptoms</p>
                        <div className="flex flex-wrap gap-1.5">
                          {log.symptoms.map(s => (
                            <span key={s} className="px-2 py-1 rounded-lg bg-amber-50 border border-amber-200 text-amber-700 text-[10px] font-mono">
                              {s}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {log.prescription_plant && (
                      <div className="p-3 bg-green-50 border border-green-200 rounded-xl">
                        <p className="text-green-700 text-xs font-mono">
                          <span className="font-bold">Prescription:</span> {log.prescription_plant}
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
