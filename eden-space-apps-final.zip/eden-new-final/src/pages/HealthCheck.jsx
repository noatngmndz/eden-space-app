import { useState } from 'react'
import { supabase } from '../lib/supabase'
import { analyzeHealth } from '../lib/rulesEngine'
import { useAuth } from '../App'

const SYMPTOMS = [
  { key: 'fatigue',           label: 'Fatigue'             },
  { key: 'headache',          label: 'Headache'            },
  { key: 'muscle_pain',       label: 'Muscle Pain'         },
  { key: 'joint_pain',        label: 'Joint Pain'          },
  { key: 'back_pain',         label: 'Back Pain'           },
  { key: 'dizziness',         label: 'Dizziness'           },
  { key: 'inflammation',      label: 'Inflammation'        },
  { key: 'nausea',            label: 'Nausea'              },
  { key: 'loss_of_appetite',  label: 'Loss of Appetite'    },
  { key: 'dehydration',       label: 'Dehydration'         },
  { key: 'fluid_retention',   label: 'Fluid Retention'     },
  { key: 'chest_tightness',   label: 'Chest Tightness'     },
  { key: 'shortness_breath',  label: 'Shortness of Breath' },
  { key: 'vision_blur',       label: 'Vision Blur'         },
  { key: 'motion_sickness',   label: 'Motion Sickness'     },
  { key: 'anxiety',           label: 'Anxiety'             },
  { key: 'cognitive_fatigue', label: 'Cognitive Fatigue'   },
  { key: 'focus_issues',      label: 'Focus Issues'        },
  { key: 'insomnia',          label: 'Insomnia'            },
  { key: 'memory_lapses',     label: 'Memory Lapses'       },
]

const LEVEL_COLOR = {
  NOMINAL:  '#6AA6DA',
  CAUTION:  '#facc15',
  CRITICAL: '#f87171',
}

const initScores = Object.fromEntries(SYMPTOMS.map(s => [s.key, 0]))

export default function HealthCheck() {
  const [form, setForm] = useState({
    sleep_quality: 70, energy_level: 70, mood: 70,
    heart_rate: 70, days_in_space: 30, symptoms: [],
  })
  const [scores,  setScores]  = useState(initScores)
  const [result,  setResult]  = useState(null)
  const [saving,  setSaving]  = useState(false)
  const [saved,   setSaved]   = useState(false)
  const { user } = useAuth()

  function setScore(key, val) {
    setScores(prev => ({ ...prev, [key]: val }))
  }

  function run() {
    const activeSymptoms = SYMPTOMS
      .filter(s => scores[s.key] >= 1)
      .map(s => s.label)
    const updated = { ...form, symptoms: activeSymptoms }
    setForm(updated)
    setResult(analyzeHealth(updated))
    setSaved(false)
  }

  async function save() {
    if (!result) return
    setSaving(true)
    const { error } = await supabase.from('astronaut_log').insert({
      ...form,
      user_id:               user?.id ?? null,
      stress_level:          result.stress_level,
      inflammation_level:    result.inflammation_level,
      cognitive_level:       result.cognitive_level,
      cardiovascular_level:  result.cardiovascular_level,
      prescription_plant:    result.prescriptions.join(', '),
    })
    setSaving(false)
    if (!error) setSaved(true)
    else alert('Error saving. Check your internet connection.')
  }

  const accent = LEVEL_COLOR[result?.overall] ?? '#6AA6DA'

  return (
    <div className="max-w-2xl mx-auto space-y-5">
      <div>
        <h1 className="text-lg font-bold text-black">Health Check</h1>
        <p className="text-black/30 text-xs font-mono mt-0.5">Enter your biometrics. E.D.E.N. diagnoses and prescribes.</p>
      </div>

      {/* Biometrics */}
      <div className="bg-white border border-black/8 rounded-2xl p-5 space-y-5">
        <p className="text-black/35 text-[10px] font-mono uppercase tracking-wider">Biometrics</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <Slider label="Sleep Quality"  value={form.sleep_quality}  min={1}  max={100} unit="%"    onChange={v => setForm(f => ({ ...f, sleep_quality: v }))} warn={form.sleep_quality < 30} />
          <Slider label="Energy Level"   value={form.energy_level}   min={1}  max={100} unit="%"    onChange={v => setForm(f => ({ ...f, energy_level: v }))} warn={form.energy_level < 30} />
          <Slider label="Mood"           value={form.mood}           min={1}  max={100} unit="%"    onChange={v => setForm(f => ({ ...f, mood: v }))} warn={form.mood < 30} />
          <Slider label="Heart Rate"     value={form.heart_rate}     min={40} max={150} unit=" bpm" warn={form.heart_rate > 100 || form.heart_rate < 50} onChange={v => setForm(f => ({ ...f, heart_rate: v }))} />
          <Slider label="Days in Space"  value={form.days_in_space}  min={1}  max={500} unit=" days" onChange={v => setForm(f => ({ ...f, days_in_space: v }))} />
        </div>
      </div>

      {/* Symptom Severity */}
      <div className="bg-white border border-black/8 rounded-2xl p-5 space-y-5">
        <div>
          <p className="text-black/35 text-[10px] font-mono uppercase tracking-wider">Symptom Severity</p>
          <p className="text-black/20 text-[10px] font-mono mt-0.5">0 = none &nbsp;·&nbsp; 100 = severe</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-5">
          {SYMPTOMS.map(s => (
            <Slider
              key={s.key}
              label={s.label}
              value={scores[s.key]}
              min={0}
              max={100}
              unit="%"
              warn={scores[s.key] >= 70}
              onChange={v => setScore(s.key, v)}
            />
          ))}
        </div>
      </div>

      <button onClick={run}
        className="w-full bg-[#6AA6DA] hover:bg-[#5a96ca] text-white font-bold py-3 rounded-xl transition-all text-sm">
        Run Diagnostic
      </button>

      {result && (
        <div className="bg-white rounded-2xl p-5 space-y-4"
          style={{ border: `1px solid ${accent}40` }}>
          <div className="flex items-start justify-between">
            <div>
              <p className="text-black/35 text-[10px] font-mono uppercase tracking-wider">Diagnostic Result</p>
              <p className="text-3xl font-bold font-mono mt-1" style={{ color: accent }}>{result.overall}</p>
            </div>
            <div className="text-right text-[10px] font-mono space-y-0.5">
              {[['Stress', result.stress_level], ['Inflam.', result.inflammation_level],
                ['Cognitive', result.cognitive_level], ['Cardio', result.cardiovascular_level],
              ].map(([k, v]) => (
                <div key={k} className="text-black/30">{k}: <span className="text-black/60">{v}</span></div>
              ))}
            </div>
          </div>

          {result.alerts.length > 0 && (
            <div className="space-y-2">
              <p className="text-black/35 text-[10px] font-mono uppercase tracking-wider">Alerts</p>
              {result.alerts.map((a, i) => (
                <div key={i} className={`flex gap-2 items-start p-2.5 rounded-xl text-xs font-mono ${
                  a.type === 'danger'
                    ? 'bg-red-50 border border-red-200 text-red-700'
                    : 'bg-amber-50 border border-amber-200 text-amber-700'
                }`}>
                  <span className="font-bold opacity-60 shrink-0">[{a.system}]</span>
                  <span className="text-black/60">{a.msg}</span>
                </div>
              ))}
            </div>
          )}

          {form.symptoms.length > 0 && (
            <div>
              <p className="text-black/35 text-[10px] font-mono uppercase tracking-wider mb-2">Reported Symptoms</p>
              <div className="flex flex-wrap gap-1.5">
                {form.symptoms.map(s => (
                  <span key={s} className="px-2 py-0.5 rounded-full bg-amber-50 border border-amber-200 text-amber-700 text-[10px] font-mono">
                    {s}
                  </span>
                ))}
              </div>
            </div>
          )}

          {result.prescriptions.length > 0 && (
            <div>
              <p className="text-black/35 text-[10px] font-mono uppercase tracking-wider mb-2">Prescribed Plants</p>
              <div className="flex flex-wrap gap-2">
                {result.prescriptions.map(p => (
                  <span key={p} className="px-3 py-1 rounded-full bg-green-50 border border-green-200 text-green-700 text-xs font-mono">
                    {p}
                  </span>
                ))}
              </div>
            </div>
          )}

          {!saved ? (
            <button onClick={save} disabled={saving}
              className="w-full bg-[#FBFBF8] hover:bg-[#DBE3E9] border border-black/8 text-black/60 font-medium py-2.5 rounded-xl transition-all text-sm disabled:opacity-40">
              {saving ? 'Saving...' : 'Save to Mission Log'}
            </button>
          ) : (
            <p className="text-center text-[#6AA6DA] font-mono text-sm py-2">Saved to Mission Log</p>
          )}
        </div>
      )}
    </div>
  )
}

function Slider({ label, value, min, max, unit, warn, onChange }) {
  function handleInput(e) {
    const v = Number(e.target.value)
    if (!isNaN(v) && v >= min && v <= max) onChange(v)
  }

  return (
    <div>
      <div className="flex items-center justify-between text-xs mb-2 gap-2">
        <span className="text-black/40 font-mono shrink-0">{label}</span>
        <div className="flex items-center gap-1.5">
          <input
            type="number" min={min} max={max} value={value}
            onChange={handleInput}
            className={`w-16 text-right font-mono font-bold text-xs border rounded-lg px-2 py-0.5 bg-[#FBFBF8] focus:outline-none ${
              warn ? 'border-red-300 text-red-500 focus:border-red-400' : 'border-black/15 text-black/70 focus:border-[#6AA6DA]/50'
            }`}
          />
          <span className="text-black/30 font-mono text-[10px] shrink-0">{unit}</span>
        </div>
      </div>
      <input type="range" min={min} max={max} value={value}
        onChange={e => onChange(Number(e.target.value))}
        className="w-full"
        style={{ accentColor: warn ? '#f87171' : '#6AA6DA' }}
      />
      <div className="flex justify-between text-[10px] text-black/20 font-mono mt-0.5">
        <span>{min}</span><span>{max}</span>
      </div>
    </div>
  )
}
