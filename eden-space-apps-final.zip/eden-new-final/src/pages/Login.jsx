import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { signIn, submitAccessRequest } from '../lib/auth'

const ROLES = ['paciente', 'doctor', 'programador', 'admin']

const ROLE_LABEL = {
  paciente: 'Astronaut / Patient',
  doctor: 'Doctor',
  programador: 'Engineer',
  admin: 'Administrator',
}

const ROLE_DESC = {
  paciente: 'Access your health data and diagnostic log',
  doctor: 'Clinical view of all patients and their records',
  programador: 'System technical metrics and DB status',
  admin: 'Access management, requests and system audit log',
}

export default function Login() {
  const navigate = useNavigate()
  const [tab, setTab]           = useState('login')   // 'login' | 'request'
  const [role, setRole]         = useState('paciente')
  const [email, setEmail]       = useState('')
  const [password, setPassword] = useState('')
  const [error, setError]       = useState(null)
  const [loading, setLoading]   = useState(false)
  const [success, setSuccess]   = useState(false)

  // Request form
  const [reqName, setReqName]     = useState('')
  const [reqEmail, setReqEmail]   = useState('')
  const [reqRole, setReqRole]     = useState('paciente')
  const [reqReason, setReqReason] = useState('')

  async function handleLogin(e) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      await signIn(email, password)
      navigate('/')
    } catch (err) {
      console.error('Supabase login error:', err)
      setError(err.message || 'Invalid credentials. Check your email and password.')
    } finally {
      setLoading(false)
    }
  }

  async function handleRequest(e) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      await submitAccessRequest({
        full_name: reqName,
        email: reqEmail,
        role_requested: reqRole,
        reason: reqReason,
      })
      setSuccess(true)
    } catch (err) {
      setError('Error submitting request. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-[#FBFBF8] flex items-center justify-center px-4">
      <div className="w-full max-w-sm">

        {/* Logo */}
        <div className="text-center mb-8">
          <p className="text-black font-bold text-2xl tracking-widest font-mono">E.D.E.N.</p>
          <p className="text-black/30 text-xs font-mono mt-1">Ecosystem Diagnostic &amp; Emergency Nutrition</p>
        </div>

        {/* Tab switcher */}
        <div className="flex gap-1 mb-6 bg-[#DBE3E9] rounded-xl p-1">
          {['login', 'request'].map(t => (
            <button key={t} onClick={() => { setTab(t); setError(null); setSuccess(false) }}
              className={`flex-1 py-2 text-xs font-medium rounded-lg transition-all ${
                tab === t
                  ? 'bg-white text-[#6AA6DA] border border-[#6AA6DA]/25 shadow-sm'
                  : 'text-black/40 hover:text-black/60'
              }`}>
              {t === 'login' ? 'Sign In' : 'Request Access'}
            </button>
          ))}
        </div>

        {tab === 'login' ? (
          <form onSubmit={handleLogin} className="space-y-4">
            {/* Role selector */}
            <div>
              <p className="text-black/40 text-[10px] font-mono uppercase tracking-wider mb-2">Access Profile</p>
              <div className="grid grid-cols-2 gap-2">
                {ROLES.map(r => (
                  <button key={r} type="button" onClick={() => setRole(r)}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      role === r
                        ? 'border-[#6AA6DA]/40 bg-[#6AA6DA]/10'
                        : 'border-black/8 bg-white hover:bg-[#DBE3E9]/40'
                    }`}>
                    <p className={`text-xs font-semibold ${role === r ? 'text-[#6AA6DA]' : 'text-black/60'}`}>
                      {ROLE_LABEL[r]}
                    </p>
                    <p className="text-black/30 text-[9px] font-mono mt-0.5 leading-tight">{ROLE_DESC[r]}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Credentials */}
            <div>
              <label className="text-black/40 text-[10px] font-mono uppercase tracking-wider block mb-1.5">
                Email
              </label>
              <input
                type="email" required value={email} onChange={e => setEmail(e.target.value)}
                placeholder="user@eden.space"
                className="w-full bg-white border border-black/10 rounded-xl px-4 py-2.5 text-black text-sm font-mono placeholder:text-black/25 focus:outline-none focus:border-[#6AA6DA]/50 focus:ring-1 focus:ring-[#6AA6DA]/20"
              />
            </div>
            <div>
              <label className="text-black/40 text-[10px] font-mono uppercase tracking-wider block mb-1.5">
                Password
              </label>
              <input
                type="password" required value={password} onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-white border border-black/10 rounded-xl px-4 py-2.5 text-black text-sm font-mono placeholder:text-black/25 focus:outline-none focus:border-[#6AA6DA]/50 focus:ring-1 focus:ring-[#6AA6DA]/20"
              />
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-2.5 text-red-600 text-xs font-mono">
                {error}
              </div>
            )}

            <button type="submit" disabled={loading}
              className="w-full bg-[#6AA6DA] hover:bg-[#5a96ca] disabled:opacity-50 text-white font-bold py-2.5 rounded-xl text-sm transition-colors">
              {loading ? 'Verifying...' : 'Sign In'}
            </button>
          </form>

        ) : success ? (
          <div className="bg-green-50 border border-green-200 rounded-2xl p-6 text-center">
            <div className="w-10 h-10 rounded-full bg-green-100 border border-green-300 flex items-center justify-center mx-auto mb-3">
              <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <p className="text-green-700 font-semibold text-sm">Request submitted</p>
            <p className="text-black/40 text-xs font-mono mt-1">The administrator will review your request and notify you by email.</p>
            <button onClick={() => { setSuccess(false); setTab('login') }}
              className="mt-4 text-[#6AA6DA] text-xs font-mono hover:underline">
              Back to sign in
            </button>
          </div>
        ) : (
          <form onSubmit={handleRequest} className="space-y-4">
            <div>
              <label className="text-black/40 text-[10px] font-mono uppercase tracking-wider block mb-1.5">Full Name</label>
              <input required value={reqName} onChange={e => setReqName(e.target.value)}
                placeholder="Alex Commander"
                className="w-full bg-white border border-black/10 rounded-xl px-4 py-2.5 text-black text-sm font-mono placeholder:text-black/25 focus:outline-none focus:border-[#6AA6DA]/50 focus:ring-1 focus:ring-[#6AA6DA]/20" />
            </div>
            <div>
              <label className="text-black/40 text-[10px] font-mono uppercase tracking-wider block mb-1.5">Email</label>
              <input type="email" required value={reqEmail} onChange={e => setReqEmail(e.target.value)}
                placeholder="user@eden.space"
                className="w-full bg-white border border-black/10 rounded-xl px-4 py-2.5 text-black text-sm font-mono placeholder:text-black/25 focus:outline-none focus:border-[#6AA6DA]/50 focus:ring-1 focus:ring-[#6AA6DA]/20" />
            </div>
            <div>
              <label className="text-black/40 text-[10px] font-mono uppercase tracking-wider block mb-2">Requested Role</label>
              <div className="grid grid-cols-2 gap-2">
                {ROLES.map(r => (
                  <button key={r} type="button" onClick={() => setReqRole(r)}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      reqRole === r
                        ? 'border-[#6AA6DA]/40 bg-[#6AA6DA]/10'
                        : 'border-black/8 bg-white hover:bg-[#DBE3E9]/40'
                    }`}>
                    <p className={`text-xs font-semibold ${reqRole === r ? 'text-[#6AA6DA]' : 'text-black/50'}`}>
                      {ROLE_LABEL[r]}
                    </p>
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-black/40 text-[10px] font-mono uppercase tracking-wider block mb-1.5">Reason / Justification</label>
              <textarea required value={reqReason} onChange={e => setReqReason(e.target.value)}
                placeholder="Briefly explain why you need access..."
                rows={3}
                className="w-full bg-white border border-black/10 rounded-xl px-4 py-2.5 text-black text-sm font-mono placeholder:text-black/25 focus:outline-none focus:border-[#6AA6DA]/50 focus:ring-1 focus:ring-[#6AA6DA]/20 resize-none" />
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-2.5 text-red-600 text-xs font-mono">
                {error}
              </div>
            )}

            <button type="submit" disabled={loading}
              className="w-full bg-[#6AA6DA] hover:bg-[#5a96ca] disabled:opacity-50 text-white font-bold py-2.5 rounded-xl text-sm transition-colors">
              {loading ? 'Sending...' : 'Request Access'}
            </button>
          </form>
        )}

        <p className="text-center text-black/20 text-[9px] font-mono mt-6">
          NASA Space Apps 2026 — Team Dyeus
        </p>
      </div>
    </div>
  )
}
